from __future__ import annotations

import flet as ft

from app.container import ServiceContainer
from app.developer.diagnostics_service import DiagnosticsService
from app.developer.panels.branding_panel import BrandingPanel
from app.developer.code_service import CodeService
from app.developer.panels.code_panel import CodePanel
from app.developer.panels.diagnostics_panel import DiagnosticsPanel
from app.developer.panels.tools_panel import ToolsPanel
from app.ui import components as ui
from app.ui.theme import Palette, Spacing, build_theme

PANELS = {"branding": ("Brand", BrandingPanel),
          "diagnostics": ("Health", DiagnosticsPanel),
          "code": ("Code", CodePanel),
          "tools": ("Tools", ToolsPanel)}


class DeveloperApp:
    def __init__(self, page: ft.Page, services: ServiceContainer | None = None,
                 diagnostics: DiagnosticsService | None = None) -> None:
        self.page = page
        self.services = services or ServiceContainer()
        self.diagnostics = diagnostics or DiagnosticsService(self.services.db)
        self.code = CodeService()
        self.active_panel = None
        self.file_picker = ft.FilePicker()
        self.current_key = "branding"
        self.tabs_holder = ft.Container()
        self.body = ft.Container(expand=True)

    def start(self) -> None:
        page = self.page
        page.title = "PisoPasa Developer Console"
        page.theme = build_theme()
        page.dark_theme = build_theme()
        page.theme_mode = ft.ThemeMode.LIGHT
        page.bgcolor = Palette.PAPER
        page.padding = 0
        page.window.width = 460
        page.window.height = 820
        page.services.append(self.file_picker)
        page.appbar = ft.AppBar(
            bgcolor=Palette.INK, center_title=False,
            title=ft.Row([ui.logo_mark(self.services.branding.logo_bytes(), 32),
                          ft.Text("Developer Console", color=Palette.ON_DARK, weight=ft.FontWeight.W_800),
                          ui.status_pill("DEV", Palette.GREEN)], spacing=10))
        page.add(ft.SafeArea(expand=True, content=ft.Container(
            expand=True, padding=ft.Padding.all(Spacing.MD),
            content=ft.Column([self.tabs_holder, ft.Column([self.body], scroll=ft.ScrollMode.AUTO, expand=True)],
                              spacing=Spacing.MD, expand=True,
                              horizontal_alignment=ft.CrossAxisAlignment.STRETCH))))
        self.show("branding")

    def show(self, key: str) -> None:
        self.current_key = key
        self.tabs_holder.content = ui.pill_tabs([(k, v[0]) for k, v in PANELS.items()], key, self.show)
        self.active_panel = PANELS[key][1](self)
        self.body.content = self.active_panel.build()
        self.page.update()
