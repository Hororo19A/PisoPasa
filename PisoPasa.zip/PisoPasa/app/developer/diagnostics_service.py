from __future__ import annotations

import platform
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from app.config import APP_VERSION, PROJECT_ROOT, backup_dir, db_path, log_path
from app.database.connection import Database
from app.database.migrations import LATEST_VERSION, current_version

TABLES = ["trips", "legs", "favorites", "favorite_legs", "savings", "goals", "settings", "fare_matrix"]
USER_DATA_TABLES = ["savings", "goals", "favorite_legs", "favorites", "legs", "trips"]


class DiagnosticsService:
    def __init__(self, db: Database, database_file: Path | None = None,
                 log_file: Path | None = None, backup_folder: Path | None = None) -> None:
        self.db = db
        self.database_file = database_file or db_path()
        self.log_file = log_file or log_path()
        self.backup_folder = backup_folder

    def integrity(self) -> str:
        row = self.db.query_one("PRAGMA integrity_check")
        return row[0] if row else "unknown"

    def table_counts(self) -> dict[str, int]:
        return {t: self.db.query_one(f"SELECT COUNT(*) AS c FROM {t}")["c"] for t in TABLES}

    def db_size_kb(self) -> float:
        try:
            return round(self.database_file.stat().st_size / 1024, 1)
        except OSError:
            return 0.0

    def versions(self) -> dict[str, str]:
        try:
            import flet
            flet_version = getattr(flet, "__version__", "") or "installed"
        except ImportError:
            flet_version = "not installed"
        return {"App": APP_VERSION,
                "Schema": f"v{current_version(self.db.conn)} (latest v{LATEST_VERSION})", "Python": platform.python_version(), "Flet": flet_version,
                "Database": str(self.database_file)}

    def read_log(self, lines: int = 80) -> str:
        if not self.log_file.is_file():
            return "(no log yet: no errors recorded)"
        text = self.log_file.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(text[-lines:]) or "(log is empty)"

    def clear_log(self) -> None:
        self.log_file.write_text("", encoding="utf-8")

    def optimize(self) -> None:
        self.db.conn.execute("REINDEX")
        self.db.conn.execute("VACUUM")
        self.db.conn.commit()

    def backup(self) -> Path:
        folder = self.backup_folder or backup_dir()
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / f"pisopasa_backup_{datetime.now():%Y%m%d_%H%M%S}.db"
        dest = sqlite3.connect(str(target))
        try:
            self.db.conn.backup(dest)
        finally:
            dest.close()
        return target

    def reset_user_data(self, keep_fare_matrix: bool = True) -> None:
        for table in USER_DATA_TABLES:
            self.db.execute(f"DELETE FROM {table}")
        self.db.execute("DELETE FROM settings")
        if not keep_fare_matrix:
            self.db.execute("DELETE FROM fare_matrix")

    def run_self_tests(self) -> tuple[bool, str]:
        try:
            proc = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"],
                                  cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=120)
        except (OSError, subprocess.TimeoutExpired) as err:
            return False, f"Could not run tests: {err}"
        return proc.returncode == 0, (proc.stdout + proc.stderr).strip()[-2500:]
