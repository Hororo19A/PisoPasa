from __future__ import annotations

import flet as ft

from app.developer.panels.base_panel import BasePanel
from app.ui import components as ui
from app.ui.theme import FontSize, Palette


class BrandingPanel(BasePanel):
    def build(self) -> ft.Control:
        branding = self.services.branding
        logo = branding.logo_bytes()
        path = branding.logo_path()
        buttons: list[ft.Control] = [ui.primary_button("Upload logo", ft.Icons.UPLOAD, self._pick)]
        if logo:
            buttons.append(ui.soft_button("Remove", ft.Icons.DELETE_OUTLINE, self._remove))
        return self.column([
            ui.card(ft.Column([
                ui.section_label("App logo"),
                ft.Row([ui.logo_mark(logo, 84),
                        ft.Text("PNG, JPG, WEBP or GIF, up to 2 MB. A square image works best.",
                                size=FontSize.CAPTION, color=Palette.MUTED, expand=True)], spacing=14),
                ft.Text(f"File: {path}" if path else "No custom logo: the default ₱ mark is used.",
                        size=FontSize.CAPTION, color=Palette.MUTED, selectable=True),
                ft.Row(buttons, wrap=True, spacing=8)], spacing=12)),
            ui.card(ft.Column([
                ui.section_label("How it reaches users"),
                ft.Text("The logo is saved inside the app (app/branding). A running app picks it up within "
                        "about 15 seconds; new installs get it with the next build (flet build apk).",
                        size=FontSize.BODY, color=Palette.INK)], spacing=8)),
        ])

    async def _pick(self, _e) -> None:
        files = await self.app.file_picker.pick_files(
            dialog_title="Choose the app logo", file_type=ft.FilePickerFileType.IMAGE)
        if not files:
            return
        if not files[0].path:
            ui.notify(self.page, "Logo upload needs the desktop app, not the browser.", Palette.WARNING)
            return
        try:
            self.services.branding.set_logo(files[0].path)
        except ValueError as err:
            ui.notify(self.page, str(err), Palette.DANGER)
            return
        ui.notify(self.page, "Logo updated for the app.", Palette.GREEN)
        self.refresh()

    def _remove(self, _e) -> None:
        self.services.branding.remove_logo()
        ui.notify(self.page, "Logo removed. Default mark restored.", Palette.INK)
        self.refresh()
