from __future__ import annotations

import flet as ft

from app.developer.panels.base_panel import BasePanel
from app.ui import components as ui
from app.ui.theme import FontSize, Palette


class DiagnosticsPanel(BasePanel):
    def build(self) -> ft.Control:
        integrity = self.diag.integrity()
        healthy = integrity == "ok"
        counts = self.diag.table_counts()
        versions = self.diag.versions()

        def kv(k: str, v: str) -> ft.Control:
            return ft.Row([ft.Text(k, size=FontSize.BODY, color=Palette.MUTED, expand=True),
                           ft.Text(v, size=FontSize.BODY, weight=ft.FontWeight.W_700, color=Palette.INK,
                                   selectable=True)])

        return self.column([
            ui.hero_card(ft.Column([
                ft.Row([ft.Text("Database", color=Palette.ON_DARK, weight=ft.FontWeight.W_700,
                                size=FontSize.SUBTITLE, expand=True),
                        ui.status_pill("Healthy" if healthy else "Problem found",
                                       Palette.GREEN if healthy else Palette.DANGER)]),
                ft.Text(f"Integrity: {integrity}", color=Palette.ON_DARK_MUTED, size=FontSize.CAPTION),
                ft.Text(f"{self.diag.db_size_kb()} KB", color=Palette.ON_DARK, size=26,
                        weight=ft.FontWeight.W_900)], spacing=4)),
            ui.card(ft.Column([ui.section_label("Rows per table"),
                               *[kv(t, str(c)) for t, c in counts.items()]], spacing=8)),
            ui.card(ft.Column([ui.section_label("Versions"),
                               *[kv(k, v) for k, v in versions.items()]], spacing=8)),
            ui.card(ft.Column([
                ui.section_label("Error log (latest)"),
                ft.Container(
                    content=ft.Text(self.diag.read_log(), size=11, font_family="monospace",
                                    color=Palette.ON_DARK, selectable=True),
                    bgcolor=Palette.INK, padding=ft.Padding.all(12),
                    border_radius=ft.BorderRadius.all(14)),
                ft.Row([ui.soft_button("Refresh", ft.Icons.REFRESH, lambda _e: self.refresh()),
                        ui.soft_button("Clear log", ft.Icons.DELETE_OUTLINE, self._clear)], spacing=8)],
                spacing=10)),
        ])

    def _clear(self, _e) -> None:
        self.diag.clear_log()
        self.refresh()
