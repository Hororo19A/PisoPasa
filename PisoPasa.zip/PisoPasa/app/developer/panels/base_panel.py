from __future__ import annotations

from typing import TYPE_CHECKING

import flet as ft

from app.ui.theme import Spacing

if TYPE_CHECKING:
    from app.developer.dev_app import DeveloperApp


class BasePanel:
    def __init__(self, app: "DeveloperApp") -> None:
        self.app = app
        self.page = app.page
        self.services = app.services
        self.diag = app.diagnostics

    def build(self) -> ft.Control:
        raise NotImplementedError

    def column(self, controls: list[ft.Control]) -> ft.Column:
        return ft.Column(controls, spacing=Spacing.MD, horizontal_alignment=ft.CrossAxisAlignment.STRETCH)

    def refresh(self) -> None:
        self.app.show(self.app.current_key)
