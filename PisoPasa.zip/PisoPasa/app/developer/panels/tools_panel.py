from __future__ import annotations

import asyncio

import flet as ft

from app.developer.panels.base_panel import BasePanel
from app.ui import components as ui
from app.ui.theme import FontSize, Palette


class ToolsPanel(BasePanel):
    def build(self) -> ft.Control:
        self.output = ft.Text("", size=11, font_family="monospace", color=Palette.ON_DARK, selectable=True)
        self.output_box = ft.Container(content=self.output, bgcolor=Palette.INK, visible=False,
                                       padding=ft.Padding.all(12), border_radius=ft.BorderRadius.all(14))
        self.keep_fares = ft.Switch(label="Keep the fare matrix", value=True, active_color=Palette.GREEN)
        return self.column([
            ui.card(ft.Column([
                ui.section_label("Self-tests"),
                ft.Text("Runs the project's test suite to catch bugs after you edit code.",
                        size=FontSize.CAPTION, color=Palette.MUTED),
                ui.primary_button("Run tests", ft.Icons.PLAY_ARROW, self._run_tests),
                self.output_box], spacing=10)),
            ui.card(ft.Column([
                ui.section_label("Database"),
                ft.Text("Back up the database, or rebuild its indexes and shrink it.",
                        size=FontSize.CAPTION, color=Palette.MUTED),
                ft.Row([ui.soft_button("Backup now", ft.Icons.SAVE_ALT, self._backup),
                        ui.soft_button("Repair / optimize", ft.Icons.BUILD, self._optimize)],
                       wrap=True, spacing=8)], spacing=10)),
            ui.card(ft.Column([
                ui.section_label("Danger zone"),
                ft.Text("Deletes all trips, favorites, savings, goals and the wallet. Back up first.",
                        size=FontSize.CAPTION, color=Palette.MUTED),
                self.keep_fares,
                ft.Button(content="Reset user data", icon=ft.Icons.WARNING_AMBER, on_click=self._reset,
                          style=ft.ButtonStyle(bgcolor=Palette.DANGER, color=Palette.ON_DARK,
                                               shape=ft.RoundedRectangleBorder(radius=40),
                                               padding=ft.Padding.symmetric(horizontal=26, vertical=16)))],
                spacing=10)),
        ])

    async def _run_tests(self, _e) -> None:
        self._show("Running tests…")
        ok, text = await asyncio.to_thread(self.diag.run_self_tests)
        self._show(("✅ All tests passed\n\n" if ok else "❌ Some tests failed\n\n") + text)

    def _show(self, text: str) -> None:
        self.output.value = text
        self.output_box.visible = True
        self.page.update()

    def _backup(self, _e) -> None:
        path = self.diag.backup()
        ui.notify(self.page, f"Backup saved: {path.name}", Palette.GREEN)

    def _optimize(self, _e) -> None:
        self.diag.optimize()
        ui.notify(self.page, "Database optimized.", Palette.GREEN)

    def _reset(self, _e) -> None:
        keep = bool(self.keep_fares.value)

        def do_reset():
            self.diag.reset_user_data(keep_fare_matrix=keep)
            ui.notify(self.page, "User data cleared.", Palette.INK)

        ui.confirm_dialog(self.page, "Reset user data", "This cannot be undone. Continue?", do_reset)
