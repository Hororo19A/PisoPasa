from __future__ import annotations

from pathlib import Path

import flet as ft

from app.developer.code_service import CodeError
from app.developer.panels.base_panel import BasePanel
from app.ui import components as ui
from app.ui.theme import FontSize, Palette


class CodePanel(BasePanel):
    cwd = ""
    open_rel = ""

    def build(self) -> ft.Control:
        code = self.app.code
        self.result = ft.Text("", size=FontSize.CAPTION, color=Palette.INK, selectable=True)
        self.upload_result = ft.Text("", size=FontSize.CAPTION, color=Palette.INK, selectable=True)
        controls: list[ft.Control] = [
            ui.info_card("Edit or upload code here",
                         "Open a file to edit it, or upload a fixed file / an update package (.zip). Python is "
                         "syntax-checked before saving and every overwritten file is backed up, so you can "
                         "always restore. With `flet run -d -r main.py` running, the app reloads by itself."),
            self._browser(code)]
        if CodePanel.open_rel:
            controls.append(self._editor(code))
        controls += [self._uploads(), self._backups(code)]
        return self.column(controls)

    def _browser(self, code) -> ft.Control:
        try:
            entries = code.list_dir(CodePanel.cwd)
        except CodeError:
            CodePanel.cwd = ""
            entries = code.list_dir("")
        rows: list[ft.Control] = []
        if CodePanel.cwd:
            rows.append(self._row(ft.Icons.ARROW_UPWARD, ".. (up)", "", self._up))
        for e in entries:
            if e.is_dir:
                rows.append(self._row(ft.Icons.FOLDER, e.name, "", lambda _e, r=e.rel: self._go(r)))
            elif e.editable:
                rows.append(self._row(ft.Icons.DESCRIPTION, e.name, f"{e.size / 1024:.1f} KB",
                                      lambda _e, r=e.rel: self._open(r)))
            else:
                rows.append(self._row(ft.Icons.INSERT_DRIVE_FILE, e.name, "not editable", None, muted=True))
        return ui.card(ft.Column([
            ui.section_label("Project files"),
            ft.Text("/" + CodePanel.cwd, size=FontSize.CAPTION, color=Palette.MUTED, selectable=True),
            ft.Column(rows, spacing=2)], spacing=8))

    @staticmethod
    def _row(icon: str, name: str, extra: str, on_click, muted: bool = False) -> ft.Control:
        color = Palette.MUTED if muted else Palette.INK
        return ft.Container(
            on_click=on_click, padding=ft.Padding.symmetric(horizontal=8, vertical=9),
            border_radius=ft.BorderRadius.all(10),
            content=ft.Row([ft.Icon(icon, size=18, color=Palette.GREEN_DARK if not muted else Palette.MUTED),
                            ft.Text(name, size=FontSize.BODY, color=color, expand=True),
                            ft.Text(extra, size=11, color=Palette.MUTED)], spacing=10))

    def _go(self, rel: str) -> None:
        CodePanel.cwd = rel
        self.refresh()

    def _up(self, _e) -> None:
        CodePanel.cwd = str(Path(CodePanel.cwd).parent) if Path(CodePanel.cwd).parent != Path(".") else ""
        self.refresh()

    def _open(self, rel: str) -> None:
        CodePanel.open_rel = rel
        self.refresh()

    def _editor(self, code) -> ft.Control:
        try:
            text = code.read(CodePanel.open_rel)
        except CodeError as err:
            CodePanel.open_rel = ""
            return ui.card(ft.Text(str(err), color=Palette.DANGER))
        self.editor = ft.TextField(
            value=text, multiline=True, min_lines=14, max_lines=28, filled=True, fill_color=Palette.TILE,
            border=ui._FIELD_BORDER, content_padding=ft.Padding.all(12), color=Palette.INK,
            text_style=ft.TextStyle(font_family="monospace", size=12, color=Palette.INK))
        return ui.card(ft.Column([
            ft.Row([ft.Icon(ft.Icons.CODE, color=Palette.GREEN_DARK),
                    ft.Text(CodePanel.open_rel, weight=ft.FontWeight.W_800, color=Palette.INK, expand=True,
                            selectable=True)], spacing=8),
            self.editor,
            ft.Row([ui.primary_button("Save", ft.Icons.SAVE, self._save),
                    ui.soft_button("Revert", ft.Icons.UNDO, lambda _e: self.refresh()),
                    ui.soft_button("Open in VS Code", ft.Icons.OPEN_IN_NEW, self._vscode),
                    ui.soft_button("Close", ft.Icons.CLOSE, self._close)], wrap=True, spacing=8),
            self.result], spacing=10))

    def _save(self, _e) -> None:
        try:
            backup = self.app.code.write(CodePanel.open_rel, self.editor.value or "")
        except CodeError as err:
            ui.notify(self.page, str(err), Palette.DANGER)
            self.result.value = f"❌ {err}"
            self.result.update()
            return
        ui.notify(self.page, f"Saved. Backup: {backup or 'new file'}", Palette.GREEN)

    def _vscode(self, _e) -> None:
        ok = self.app.code.open_in_vscode(CodePanel.open_rel)
        ui.notify(self.page, "Opened in VS Code." if ok else "VS Code command `code` not found in PATH.",
                  Palette.GREEN if ok else Palette.WARNING)

    def _close(self, _e) -> None:
        CodePanel.open_rel = ""
        self.refresh()

    def _uploads(self) -> ft.Control:
        return ui.card(ft.Column([
            ui.section_label("Upload code"),
            ft.Text(f"Into this folder: /{CodePanel.cwd}", size=FontSize.CAPTION, color=Palette.MUTED),
            ft.Row([ui.soft_button("Upload file(s)", ft.Icons.UPLOAD_FILE, self._upload_files),
                    ui.primary_button("Upload update package (.zip)", ft.Icons.FOLDER_ZIP, self._upload_zip)],
                   wrap=True, spacing=8),
            ft.Text("A package is a .zip of changed project files (for example from a teammate). Paths inside the "
                    "zip decide where each file goes.",
                    size=FontSize.CAPTION, color=Palette.MUTED),
            self.upload_result], spacing=10))

    async def _upload_files(self, _e) -> None:
        files = await self.app.file_picker.pick_files(dialog_title="Choose code file(s)", allow_multiple=True)
        if not files:
            return
        done, errors = [], []
        for f in files:
            if not f.path:
                errors.append(f"{f.name}: needs the desktop app")
                continue
            try:
                self.app.code.upload_file(f.path, CodePanel.cwd)
                done.append(f.name)
            except CodeError as err:
                errors.append(str(err))
        self._report(done, errors)

    async def _upload_zip(self, _e) -> None:
        files = await self.app.file_picker.pick_files(
            dialog_title="Choose the update package", file_type=ft.FilePickerFileType.CUSTOM,
            allowed_extensions=["zip"])
        if not files or not files[0].path:
            return
        try:
            written, skipped, backup = self.app.code.import_zip(files[0].path)
        except CodeError as err:
            ui.notify(self.page, str(err), Palette.DANGER)
            self._report([], [str(err)])
            return
        self._report(written, [f"skipped {s}" for s in skipped], backup)

    def _report(self, done: list[str], errors: list[str], backup: str = "") -> None:
        lines = []
        if done:
            lines.append(f"✅ Updated {len(done)} file(s): " + ", ".join(done[:8]) + ("…" if len(done) > 8 else ""))
        if backup:
            lines.append(f"Backup: {backup}")
        lines += [f"⚠️ {e}" for e in errors[:8]]
        ui.notify(self.page, f"Updated {len(done)} file(s)." if done else "Nothing was updated.",
                  Palette.GREEN if done else Palette.WARNING)
        self.refresh_keep_result("\n".join(lines))

    def refresh_keep_result(self, text: str) -> None:
        self.app.show(self.app.current_key)
        panel = self.app.active_panel
        if isinstance(panel, CodePanel):
            panel.upload_result.value = text
            self.page.update()

    def _backups(self, code) -> ft.Control:
        rows: list[ft.Control] = []
        for name, count in code.list_backups():
            rows.append(ft.Row([
                ft.Column([ft.Text(name, size=FontSize.BODY, color=Palette.INK, weight=ft.FontWeight.W_600),
                           ft.Text(f"{count} file(s)", size=11, color=Palette.MUTED)], spacing=0, expand=True),
                ui.soft_button("Restore", ft.Icons.RESTORE, lambda _e, n=name: self._restore(n))]))
        return ui.card(ft.Column([
            ui.section_label("Backups (undo a bad change)"),
            *(rows or [ft.Text("No backups yet. One is made every time a file is overwritten.",
                               size=FontSize.CAPTION, color=Palette.MUTED)])], spacing=8))

    def _restore(self, name: str) -> None:
        def do():
            try:
                files = self.app.code.restore_backup(name)
            except CodeError as err:
                ui.notify(self.page, str(err), Palette.DANGER)
                return
            ui.notify(self.page, f"Restored {len(files)} file(s) from {name}.", Palette.GREEN)
            self.refresh()
        ui.confirm_dialog(self.page, "Restore backup", f"Put back the files saved in {name}?", do)
