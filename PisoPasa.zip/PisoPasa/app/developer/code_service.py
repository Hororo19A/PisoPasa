from __future__ import annotations

import shutil
import subprocess
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from app.config import PROJECT_ROOT, data_dir

IGNORED_DIRS = {".git", ".venv", "venv", "__pycache__", "data", "build", "dist", "node_modules", ".idea"}
EDITABLE = {".py", ".md", ".toml", ".json", ".txt", ".cfg", ".ini", ".yml", ".yaml", ".gitignore"}
MAX_FILE_BYTES = 300_000
MAX_ZIP_BYTES = 30 * 1024 * 1024
MAX_ZIP_FILES = 1000


class CodeError(ValueError):
    pass


@dataclass
class Entry:
    name: str
    rel: str
    is_dir: bool
    editable: bool
    size: int = 0


class CodeService:
    def __init__(self, root: Path = PROJECT_ROOT, backup_root: Path | None = None) -> None:
        self.root = Path(root).resolve()
        self.backup_root = Path(backup_root) if backup_root else data_dir() / "code_backups"

    def _safe(self, rel: str) -> Path:
        path = (self.root / rel).resolve()
        if path != self.root and self.root not in path.parents:
            raise CodeError("That path is outside the project.")
        if any(part in IGNORED_DIRS for part in path.relative_to(self.root).parts):
            raise CodeError("That folder is not available here.")
        return path

    @staticmethod
    def is_editable(path: Path) -> bool:
        return path.suffix.lower() in EDITABLE or path.name == ".gitignore"

    def list_dir(self, rel: str = "") -> list[Entry]:
        folder = self._safe(rel)
        if not folder.is_dir():
            raise CodeError("Not a folder.")
        entries: list[Entry] = []
        for child in sorted(folder.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
            if child.name in IGNORED_DIRS or child.suffix == ".pyc":
                continue
            child_rel = child.relative_to(self.root).as_posix()
            entries.append(Entry(child.name, child_rel, child.is_dir(), child.is_dir() or self.is_editable(child),
                                 child.stat().st_size if child.is_file() else 0))
        return entries

    def read(self, rel: str) -> str:
        path = self._safe(rel)
        if not path.is_file() or not self.is_editable(path):
            raise CodeError("This file type cannot be edited here.")
        if path.stat().st_size > MAX_FILE_BYTES:
            raise CodeError("File is too large to edit here. Use VS Code.")
        return path.read_text(encoding="utf-8", errors="replace")

    @staticmethod
    def check_python(rel: str, data: bytes) -> None:
        if rel.endswith(".py"):
            try:
                compile(data.decode("utf-8"), rel, "exec")
            except SyntaxError as err:
                raise CodeError(f"Syntax error in {rel}, line {err.lineno}: {err.msg}") from None
            except UnicodeDecodeError:
                raise CodeError(f"{rel} is not valid UTF-8 text.") from None

    def _new_stamp(self, prefix: str = "") -> Path:
        base = f"{prefix}{datetime.now():%Y%m%d_%H%M%S}"
        path, n = self.backup_root / base, 1
        while path.exists():
            n += 1
            path = self.backup_root / f"{base}_{n}"
        return path

    def _commit(self, changes: dict[str, bytes], prefix: str = "") -> str:
        for rel, data in changes.items():
            self._safe(rel)
            if not self.is_editable(Path(rel)):
                raise CodeError(f"{rel}: this file type cannot be uploaded here.")
            if len(data) > MAX_FILE_BYTES * 3:
                raise CodeError(f"{rel} is too large.")
            self.check_python(rel, data)
        stamp = self._new_stamp(prefix)
        for rel, data in changes.items():
            path = self._safe(rel)
            if path.exists():
                backup = stamp / rel
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, backup)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        return stamp.name if stamp.exists() else ""

    def write(self, rel: str, text: str) -> str:
        return self._commit({rel: text.encode("utf-8")})

    def upload_file(self, source: str | Path, dest_dir: str = "") -> str:
        source = Path(source)
        if not source.is_file():
            raise CodeError("The selected file could not be read.")
        rel = (Path(dest_dir) / source.name).as_posix() if dest_dir else source.name
        return self._commit({rel: source.read_bytes()})

    def import_zip(self, zip_path: str | Path) -> tuple[list[str], list[str], str]:
        zip_path = Path(zip_path)
        if not zipfile.is_zipfile(zip_path):
            raise CodeError("That is not a valid .zip file.")
        with zipfile.ZipFile(zip_path) as zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            if len(infos) > MAX_ZIP_FILES or sum(i.file_size for i in infos) > MAX_ZIP_BYTES:
                raise CodeError("Package is too large.")
            names = [i.filename.replace("\\", "/").lstrip("/") for i in infos]
            firsts = {n.split("/", 1)[0] for n in names if "/" in n}
            strip = ""
            if len(firsts) == 1 and all("/" in n for n in names):
                top = next(iter(firsts))
                if not (self.root / top).exists():
                    strip = top + "/"
            changes: dict[str, bytes] = {}
            skipped: list[str] = []
            for info, name in zip(infos, names):
                rel = name[len(strip):] if strip and name.startswith(strip) else name
                parts = Path(rel).parts
                if (".." in parts or not parts or any(p in IGNORED_DIRS for p in parts)
                        or not self.is_editable(Path(rel))):
                    skipped.append(rel)
                    continue
                changes[rel] = zf.read(info)
        if not changes:
            raise CodeError("Nothing to update: the package has no editable project files.")
        backup = self._commit(changes)
        return sorted(changes), sorted(skipped), backup

    def list_backups(self, limit: int = 5) -> list[tuple[str, int]]:
        if not self.backup_root.exists():
            return []
        folders = sorted((p for p in self.backup_root.iterdir() if p.is_dir()), reverse=True)[:limit]
        return [(p.name, sum(1 for f in p.rglob("*") if f.is_file())) for p in folders]

    def restore_backup(self, name: str) -> list[str]:
        folder = self.backup_root / name
        if not folder.is_dir() or folder.parent != self.backup_root:
            raise CodeError("Backup not found.")
        changes = {f.relative_to(folder).as_posix(): f.read_bytes() for f in folder.rglob("*") if f.is_file()}
        self._commit(changes, prefix="before_restore_")
        return sorted(changes)

    def open_in_vscode(self, rel: str) -> bool:
        path = self._safe(rel)
        code = shutil.which("code") or shutil.which("code.cmd")
        if not code:
            return False
        try:
            subprocess.Popen([code, "-g", str(path)])
            return True
        except OSError:
            return False
