from __future__ import annotations

from dataclasses import dataclass, field

from app.config import CURRENCY


@dataclass
class FareRule:
    vehicle: str
    base_fare: float
    base_km: float
    per_km: float


@dataclass
class Leg:
    vehicle: str
    distance_km: float
    fare: float


@dataclass
class Trip:
    origin: str
    destination: str
    legs: list[Leg] = field(default_factory=list)
    id: int | None = None
    logged_at: str = ""
    saved: bool = False

    @property
    def total(self) -> float:
        return round(sum(leg.fare for leg in self.legs), 2)

    @property
    def route_text(self) -> str:
        return f"{self.origin} → {self.destination}"


@dataclass
class FavoriteRoute:
    name: str
    origin: str
    destination: str
    legs: list[Leg] = field(default_factory=list)
    id: int | None = None

    @property
    def total(self) -> float:
        return round(sum(leg.fare for leg in self.legs), 2)


@dataclass
class RouteOption:
    label: str
    legs: list[Leg]
    total: float
    savings: float
    source: str = "matrix"
    note: str = ""


@dataclass
class SavingsGoal:
    label: str
    target: float
    saved: float = 0.0
    id: int | None = None
    achieved: bool = False

    @property
    def progress(self) -> float:
        return min(1.0, self.saved / self.target) if self.target > 0 else 0.0


@dataclass
class WalletStatus:
    starting: float
    spent: float
    remaining: float
    level: str


@dataclass
class SavingsEntry:
    created_at: str
    amount: float
    label: str = ""
    route_text: str = ""
    before_desc: str = ""
    after_desc: str = ""
    before_total: float = 0.0
    after_total: float = 0.0
    source: str = ""


def legs_text(legs: list[Leg]) -> str:
    return " + ".join(f"{l.vehicle} {CURRENCY}{l.fare:,.2f}" for l in legs)
