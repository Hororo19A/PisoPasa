from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "PisoPasa"
CURRENCY = "₱"

JEEPNEY = "Jeepney"
MODERN_JEEP = "Modern Jeep"
BUS = "Bus"
TRICYCLE = "Tricycle"
VEHICLES = [JEEPNEY, MODERN_JEEP, BUS, TRICYCLE]

LOW_BALANCE_RATIO = 0.20

MAX_ALTERNATIVES = 3


def data_dir() -> Path:
    base = os.environ.get("FLET_APP_STORAGE_DATA")
    path = Path(base) if base else Path(__file__).resolve().parent.parent / "data"
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path() -> Path:
    return data_dir() / "pisopasa.db"


def export_dir() -> Path:
    path = data_dir() / "exports"
    path.mkdir(parents=True, exist_ok=True)
    return path


BRANDING_DIR = Path(__file__).resolve().parent / "branding"
PROJECT_ROOT = Path(__file__).resolve().parent.parent
SUPPORT_EMAIL = ""
APP_VERSION = "1.0.0"


def log_path() -> Path:
    return data_dir() / "pisopasa.log"


def backup_dir() -> Path:
    path = data_dir() / "backups"
    path.mkdir(parents=True, exist_ok=True)
    return path
