SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS fare_matrix (
    vehicle   TEXT PRIMARY KEY,
    base_fare REAL NOT NULL,
    base_km   REAL NOT NULL,
    per_km    REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS trips (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    origin      TEXT NOT NULL,
    destination TEXT NOT NULL,
    total_fare  REAL NOT NULL,
    logged_at   TEXT NOT NULL,
    saved       INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS legs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id     INTEGER NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    seq         INTEGER NOT NULL,
    vehicle     TEXT NOT NULL,
    distance_km REAL NOT NULL,
    fare        REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS favorites (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    origin      TEXT NOT NULL,
    destination TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS favorite_legs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    favorite_id INTEGER NOT NULL REFERENCES favorites(id) ON DELETE CASCADE,
    seq         INTEGER NOT NULL,
    vehicle     TEXT NOT NULL,
    distance_km REAL NOT NULL,
    fare        REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS savings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id    INTEGER REFERENCES trips(id) ON DELETE SET NULL,
    amount     REAL NOT NULL,
    route_desc TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS goals (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    label      TEXT NOT NULL,
    target     REAL NOT NULL,
    saved      REAL NOT NULL DEFAULT 0,
    achieved   INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
"""

DEFAULT_FARES = [
    ("Jeepney", 13.0, 4.0, 1.80),
    ("Modern Jeep", 15.0, 4.0, 2.20),
    ("Bus", 15.0, 5.0, 2.20),
    ("Tricycle", 20.0, 2.0, 10.00),
]
