from __future__ import annotations

from datetime import datetime

from app.database.connection import Database
from app.database.schema import DEFAULT_FARES
from app.models.entities import FareRule, FavoriteRoute, Leg, SavingsEntry, SavingsGoal, Trip


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


class SettingsRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def get(self, key: str, default: str | None = None) -> str | None:
        row = self.db.query_one("SELECT value FROM settings WHERE key = ?", (key,))
        return row["value"] if row else default

    def set(self, key: str, value: str) -> None:
        self.db.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


class FareRepository:
    def __init__(self, db: Database) -> None:
        self.db = db
        if not self.db.query_one("SELECT 1 FROM fare_matrix LIMIT 1"):
            for row in DEFAULT_FARES:
                self.db.execute(
                    "INSERT INTO fare_matrix(vehicle, base_fare, base_km, per_km) "
                    "VALUES(?,?,?,?)", row)

    def all_rules(self) -> dict[str, FareRule]:
        rows = self.db.query_all("SELECT * FROM fare_matrix ORDER BY rowid")
        return {r["vehicle"]: FareRule(r["vehicle"], r["base_fare"], r["base_km"], r["per_km"])
                for r in rows}

    def update_rule(self, rule: FareRule) -> None:
        self.db.execute(
            "UPDATE fare_matrix SET base_fare=?, base_km=?, per_km=? WHERE vehicle=?",
            (rule.base_fare, rule.base_km, rule.per_km, rule.vehicle))


class TripRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def add(self, trip: Trip) -> int:
        trip_id = self.db.execute(
            "INSERT INTO trips(origin, destination, total_fare, logged_at) VALUES(?,?,?,?)",
            (trip.origin, trip.destination, trip.total, trip.logged_at or now_iso()))
        for seq, leg in enumerate(trip.legs, start=1):
            self.db.execute(
                "INSERT INTO legs(trip_id, seq, vehicle, distance_km, fare) VALUES(?,?,?,?,?)",
                (trip_id, seq, leg.vehicle, leg.distance_km, leg.fare))
        return trip_id

    def _legs(self, trip_id: int) -> list[Leg]:
        rows = self.db.query_all("SELECT * FROM legs WHERE trip_id=? ORDER BY seq", (trip_id,))
        return [Leg(r["vehicle"], r["distance_km"], r["fare"]) for r in rows]

    def _build(self, row) -> Trip:
        return Trip(row["origin"], row["destination"], self._legs(row["id"]),
                    id=row["id"], logged_at=row["logged_at"], saved=bool(row["saved"]))

    def get(self, trip_id: int) -> Trip | None:
        row = self.db.query_one("SELECT * FROM trips WHERE id=?", (trip_id,))
        return self._build(row) if row else None

    def recent(self, limit: int = 20) -> list[Trip]:
        rows = self.db.query_all("SELECT * FROM trips ORDER BY id DESC LIMIT ?", (limit,))
        return [self._build(r) for r in rows]

    def same_route_cheaper(self, origin: str, destination: str, below_total: float,
                           limit: int = 10) -> list[Trip]:
        rows = self.db.query_all(
            "SELECT * FROM trips WHERE lower(trim(origin)) = ? AND lower(trim(destination)) = ? "
            "AND total_fare < ? ORDER BY total_fare ASC, id DESC LIMIT ?",
            (origin.strip().lower(), destination.strip().lower(), below_total, limit))
        return [self._build(r) for r in rows]

    def mark_saved(self, trip_id: int) -> None:
        self.db.execute("UPDATE trips SET saved=1 WHERE id=?", (trip_id,))

    def total_since(self, since_iso: str) -> float:
        row = self.db.query_one(
            "SELECT COALESCE(SUM(total_fare),0) AS t FROM trips WHERE logged_at >= ?", (since_iso,))
        return round(row["t"], 2)

    def daily_totals_since(self, since_iso: str) -> list[tuple[str, float]]:
        rows = self.db.query_all(
            "SELECT substr(logged_at,1,10) AS d, SUM(total_fare) AS t FROM trips "
            "WHERE logged_at >= ? GROUP BY d ORDER BY d", (since_iso,))
        return [(r["d"], round(r["t"], 2)) for r in rows]

    def by_vehicle_since(self, since_iso: str) -> list[tuple[str, float]]:
        rows = self.db.query_all(
            "SELECT l.vehicle AS v, SUM(l.fare) AS t FROM legs l JOIN trips t ON t.id=l.trip_id "
            "WHERE t.logged_at >= ? GROUP BY l.vehicle ORDER BY t DESC", (since_iso,))
        return [(r["v"], round(r["t"], 2)) for r in rows]

    def by_route_since(self, since_iso: str) -> list[tuple[str, float]]:
        rows = self.db.query_all(
            "SELECT origin || ' → ' || destination AS r, SUM(total_fare) AS t FROM trips "
            "WHERE logged_at >= ? GROUP BY r ORDER BY t DESC LIMIT 5", (since_iso,))
        return [(r["r"], round(r["t"], 2)) for r in rows]

    def export_rows(self) -> list[list]:
        rows = self.db.query_all(
            "SELECT t.id, t.logged_at, t.origin, t.destination, l.seq, l.vehicle, "
            "l.distance_km, l.fare, t.total_fare FROM trips t JOIN legs l ON l.trip_id=t.id "
            "ORDER BY t.id, l.seq")
        return [list(r) for r in rows]


class FavoriteRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def add(self, fav: FavoriteRoute) -> int:
        fav_id = self.db.execute(
            "INSERT INTO favorites(name, origin, destination) VALUES(?,?,?)",
            (fav.name, fav.origin, fav.destination))
        for seq, leg in enumerate(fav.legs, start=1):
            self.db.execute(
                "INSERT INTO favorite_legs(favorite_id, seq, vehicle, distance_km, fare) "
                "VALUES(?,?,?,?,?)", (fav_id, seq, leg.vehicle, leg.distance_km, leg.fare))
        return fav_id

    def all(self) -> list[FavoriteRoute]:
        result = []
        for r in self.db.query_all("SELECT * FROM favorites ORDER BY id DESC"):
            legs = self.db.query_all(
                "SELECT * FROM favorite_legs WHERE favorite_id=? ORDER BY seq", (r["id"],))
            result.append(FavoriteRoute(
                r["name"], r["origin"], r["destination"],
                [Leg(l["vehicle"], l["distance_km"], l["fare"]) for l in legs], id=r["id"]))
        return result

    def delete(self, fav_id: int) -> None:
        self.db.execute("DELETE FROM favorites WHERE id=?", (fav_id,))


class SavingsRepository:
    def __init__(self, db: Database) -> None:
        self.db = db

    def add_saving(self, trip_id: int | None, amount: float, label: str, route_text: str = "",
                   before_desc: str = "", after_desc: str = "", before_total: float = 0.0,
                   after_total: float = 0.0, source: str = "") -> None:
        self.db.execute(
            "INSERT INTO savings(trip_id, amount, route_desc, created_at, route_text, before_desc, "
            "after_desc, before_total, after_total, source) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (trip_id, amount, label, now_iso(), route_text, before_desc, after_desc,
             before_total, after_total, source))

    def total(self) -> float:
        row = self.db.query_one("SELECT COALESCE(SUM(amount),0) AS t FROM savings")
        return round(row["t"], 2)

    def total_since(self, since_iso: str) -> float:
        row = self.db.query_one(
            "SELECT COALESCE(SUM(amount),0) AS t FROM savings WHERE created_at >= ?", (since_iso,))
        return round(row["t"], 2)

    def history(self, limit: int = 20) -> list[SavingsEntry]:
        rows = self.db.query_all("SELECT * FROM savings ORDER BY id DESC LIMIT ?", (limit,))
        return [SavingsEntry(r["created_at"], r["amount"], r["route_desc"], r["route_text"],
                             r["before_desc"], r["after_desc"], r["before_total"], r["after_total"],
                             r["source"]) for r in rows]

    def export_rows(self) -> list[list]:
        rows = self.db.query_all(
            "SELECT id, created_at, trip_id, route_text, before_desc, after_desc, before_total, "
            "after_total, amount, source, route_desc FROM savings ORDER BY id")
        return [list(r) for r in rows]

    def active_goal(self) -> SavingsGoal | None:
        r = self.db.query_one("SELECT * FROM goals WHERE achieved=0 ORDER BY id DESC LIMIT 1")
        return SavingsGoal(r["label"], r["target"], r["saved"], r["id"], bool(r["achieved"])) if r else None

    def add_goal(self, label: str, target: float) -> None:
        self.db.execute("INSERT INTO goals(label, target, created_at) VALUES(?,?,?)",
                        (label, target, now_iso()))

    def update_goal(self, goal: SavingsGoal) -> None:
        self.db.execute("UPDATE goals SET saved=?, achieved=? WHERE id=?",
                        (goal.saved, int(goal.achieved), goal.id))

    def achieved_goals(self) -> list[SavingsGoal]:
        rows = self.db.query_all("SELECT * FROM goals WHERE achieved=1 ORDER BY id DESC LIMIT 5")
        return [SavingsGoal(r["label"], r["target"], r["saved"], r["id"], True) for r in rows]
