from __future__ import annotations

import sqlite3

from app.database.schema import SCHEMA_SQL

MIGRATIONS: list[tuple[int, str]] = [
    (1, SCHEMA_SQL),
    (2, """
        ALTER TABLE savings ADD COLUMN route_text   TEXT NOT NULL DEFAULT '';
        ALTER TABLE savings ADD COLUMN before_desc  TEXT NOT NULL DEFAULT '';
        ALTER TABLE savings ADD COLUMN after_desc   TEXT NOT NULL DEFAULT '';
        ALTER TABLE savings ADD COLUMN before_total REAL NOT NULL DEFAULT 0;
        ALTER TABLE savings ADD COLUMN after_total  REAL NOT NULL DEFAULT 0;
        ALTER TABLE savings ADD COLUMN source       TEXT NOT NULL DEFAULT '';
    """),
]

LATEST_VERSION = MIGRATIONS[-1][0]


def current_version(conn: sqlite3.Connection) -> int:
    return conn.execute("PRAGMA user_version").fetchone()[0]


def migrate(conn: sqlite3.Connection) -> int:
    version = current_version(conn)
    for target, sql in MIGRATIONS:
        if target > version:
            conn.executescript(sql)
            conn.execute(f"PRAGMA user_version = {int(target)}")
            conn.commit()
            version = target
    return version
