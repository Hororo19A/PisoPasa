from __future__ import annotations

from pathlib import Path

from app.config import db_path
from app.database.connection import Database
from app.database.repositories import (FareRepository, FavoriteRepository,
                                       SavingsRepository, SettingsRepository,
                                       TripRepository)
from app.services.branding_service import BrandingService
from app.services.export_service import ExportService
from app.services.fare_calculator import FareCalculator
from app.services.favorite_service import FavoriteService
from app.services.report_service import ReportService
from app.services.route_finder_service import RouteFinderService
from app.services.savings_service import SavingsService
from app.services.trip_service import TripService
from app.services.wallet_service import WalletService


class ServiceContainer:
    def __init__(self, database_path: str | Path | None = None,
                 export_folder: Path | None = None,
                 branding_folder: Path | None = None) -> None:
        self.db = Database(database_path if database_path is not None else db_path())
        settings = SettingsRepository(self.db)
        trips = TripRepository(self.db)
        favorites = FavoriteRepository(self.db)
        savings = SavingsRepository(self.db)
        fares = FareRepository(self.db)

        self.fares = fares
        self.settings = settings
        self.calculator = FareCalculator(fares)
        self.wallet = WalletService(settings, trips)
        self.trips = TripService(trips)
        self.favorites = FavoriteService(favorites, self.trips)
        self.finder = RouteFinderService(self.calculator, trips)
        self.savings = SavingsService(savings, trips)
        self.reports = ReportService(trips, savings)
        self.export = ExportService(trips, savings, export_folder)
        self.branding = BrandingService(branding_folder)
