from __future__ import annotations

import flet as ft

from app.ui import components as ui
from app.ui.formatters import money
from app.ui.theme import FontSize, Palette, Spacing
from app.ui.views.base_view import BaseView


class FavoritesView(BaseView):
    title = "Favorites"

    def build(self) -> ft.Control:
        cards = [self._card(f) for f in self.services.favorites.all()] or [
            ui.empty_state("No favorites yet. Switch on “Save as a favorite route” when logging a trip.")]
        return self.scroll_column([
            ui.page_title("Favorite routes", "Log a regular trip with a single tap"), *cards])

    def _card(self, fav) -> ft.Control:
        top = ft.Column([
            ft.Row([ui.icon_chip(ft.Icons.STAR_ROUNDED, Palette.GREEN_LIGHT),
                    ft.Column([ft.Text(fav.name, weight=ft.FontWeight.W_800, size=FontSize.SUBTITLE,
                                       color=Palette.INK),
                               ft.Text(f"{fav.origin} → {fav.destination}", size=FontSize.CAPTION,
                                       color=Palette.MUTED)], spacing=1, expand=True)], spacing=10),
            ft.Row([ui.vehicle_chip(l.vehicle) for l in fav.legs], wrap=True, spacing=6, run_spacing=6),
        ], spacing=Spacing.SM)
        bottom = ft.Row([
            ft.Text(money(fav.total), size=FontSize.SUBTITLE + 2, weight=ft.FontWeight.W_900,
                    color=Palette.INK, expand=True),
            ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, icon_color=Palette.DANGER, tooltip="Delete",
                          on_click=lambda _e, f=fav: self._delete(f)),
            ui.accent_button("Log now", ft.Icons.BOLT, lambda _e, f=fav: self._log(f)),
        ], vertical_alignment=ft.CrossAxisAlignment.CENTER)
        return ui.ticket(top, bottom)

    def _log(self, fav) -> None:
        self.app.after_trip_logged(self.services.favorites.log_one_tap(fav))

    def _delete(self, fav) -> None:
        ui.confirm_dialog(self.page, "Delete favorite", f"Remove “{fav.name}”?",
                          lambda: (self.services.favorites.delete(fav.id), self.refresh()))
