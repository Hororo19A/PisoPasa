from __future__ import annotations

import flet as ft

from app.ui import components as ui
from app.ui.formatters import money, pretty_date
from app.ui.theme import FontSize, Palette, Spacing
from app.ui.views.base_view import BaseView


class SavingsView(BaseView):
    title = "Savings"

    def build(self) -> ft.Control:
        savings = self.services.savings
        goal = savings.active_goal()
        history = [self._history_row(e) for e in savings.history()] or [
            ui.empty_state("No savings yet. Choose a cheaper route on the Log screen to start.")]

        return self.scroll_column([
            ui.page_title("Savings", "Money you kept by switching routes"),
            ui.info_card("How savings work",
                         "On the Log screen, when you tap “Choose this route” and save the trip, the difference between "
                         "what you were going to pay and what you paid is added here. If you have a goal, it fills "
                         "automatically. Each entry below shows the trip, what you chose instead of, and what you took."),
            ui.hero_card(ft.Column([
                ft.Text("TOTAL SAVED", size=11, weight=ft.FontWeight.W_800, color=Palette.GREEN),
                ft.Text(money(savings.total()), size=FontSize.HERO, weight=ft.FontWeight.W_900,
                        color=Palette.ON_DARK)], spacing=2)),
            self._goal_card(goal),
            *[ui.card(ft.Row([ui.icon_chip(ft.Icons.FLAG, Palette.GREEN),
                              ft.Text(f"{g.label} — {money(g.target)} achieved",
                                      weight=ft.FontWeight.W_600, color=Palette.INK, expand=True)], spacing=10))
              for g in savings.achieved_goals()],
            ui.section_label("History"),
            *history,
        ])

    @staticmethod
    def _history_row(e) -> ft.Control:
        sources = {"history": "Same trip you logged before for less",
                   "matrix": "Cheaper vehicles from your fare matrix"}
        details: list[ft.Control] = [
            ft.Text(e.route_text or e.label or "Cheaper route", weight=ft.FontWeight.W_800,
                    color=Palette.INK)]
        if e.before_desc:
            details += [
                ft.Text(f"Instead of: {e.before_desc}", size=FontSize.CAPTION, color=Palette.MUTED),
                ft.Text(f"You took: {e.after_desc}", size=FontSize.CAPTION, color=Palette.INK)]
        if e.before_total:
            details.append(ft.Text(f"Paid {money(e.after_total)} instead of {money(e.before_total)}",
                                   size=FontSize.CAPTION, color=Palette.GREEN_DARK,
                                   weight=ft.FontWeight.W_600))
        footer = " · ".join(x for x in (sources.get(e.source, ""), pretty_date(e.created_at)) if x)
        details.append(ft.Text(footer, size=11, color=Palette.MUTED))
        return ui.tile(ft.Row([
            ft.Column(details, spacing=3, expand=True),
            ft.Text(f"+{money(e.amount)}", weight=ft.FontWeight.W_900, size=FontSize.SUBTITLE,
                    color=Palette.GREEN)], vertical_alignment=ft.CrossAxisAlignment.START))

    def _goal_card(self, goal) -> ft.Control:
        if goal:
            return ui.card(ui.progress_block(goal.label, goal.saved, goal.target, goal.progress))
        return ui.card(ft.Row([
            ui.icon_chip(ft.Icons.FLAG, Palette.GREEN),
            ft.Column([ft.Text("Set a savings goal", weight=ft.FontWeight.W_700, color=Palette.INK),
                       ft.Text("Pick a target; your savings fill it automatically.",
                               size=FontSize.CAPTION, color=Palette.MUTED)], spacing=2, expand=True),
            ui.primary_button("New", ft.Icons.ADD, self._open_sheet)], spacing=10))

    def _open_sheet(self, _e) -> None:
        label = ui.text_field("Goal name (e.g. New shoes)")
        stepper = ui.AmountStepper(start=500, step=50)

        def preset(value: float):
            return ft.Container(
                expand=True, alignment=ft.Alignment.CENTER, padding=ft.Padding.symmetric(vertical=12),
                bgcolor=Palette.TILE, border_radius=ft.BorderRadius.all(16),
                border=ft.Border.all(1, Palette.LINE), on_click=lambda _e: stepper.set(value),
                content=ft.Text(money(value).replace(".00", ""), weight=ft.FontWeight.W_700,
                                color=Palette.INK))

        def save(_e):
            try:
                self.services.savings.set_goal(label.value or "", stepper.value)
            except ValueError as err:
                ui.notify(self.page, str(err), Palette.DANGER)
                return
            self.page.pop_dialog()
            self.refresh()

        self.page.show_dialog(ft.BottomSheet(
            content=ft.Container(
                padding=ft.Padding.all(Spacing.MD + 4), bgcolor=Palette.SURFACE,
                content=ft.Column([
                    ft.Row([ui.soft_button("Cancel", on_click=lambda _e: self.page.pop_dialog()),
                            ft.Text("New goal", weight=ft.FontWeight.W_800, size=FontSize.SUBTITLE),
                            ui.primary_button("Save", on_click=save)],
                           alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                           vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    label, stepper.view,
                    ft.Row([preset(100), preset(500), preset(1000)], spacing=Spacing.SM),
                ], spacing=Spacing.MD, tight=True))))
