from __future__ import annotations

import flet as ft

from urllib.parse import quote

from app.config import APP_NAME, APP_VERSION, SUPPORT_EMAIL
from app.models.entities import FareRule
from app.ui import components as ui
from app.ui.formatters import money, to_float
from app.ui.theme import FontSize, Palette
from app.ui.views.base_view import BaseView


class SettingsView(BaseView):
    title = "Settings"

    def build(self) -> ft.Control:
        wallet = self.services.wallet.status()
        self.balance_box, self.balance = ui.stacked_number_field(
            "Starting fare allowance (₱)", "e.g. 500",
            f"{wallet.starting:.2f}" if wallet.level != "unset" else "")
        self.rule_fields: dict[str, tuple[ft.TextField, ft.TextField, ft.TextField]] = {}
        fare_controls: list[ft.Control] = []
        for vehicle, rule in self.services.calculator.rules().items():
            base = ui.number_field("Base ₱", f"{rule.base_fare:g}", expand=1)
            km = ui.number_field("Base km", f"{rule.base_km:g}", expand=1)
            per = ui.number_field("+₱ / km", f"{rule.per_km:g}", expand=1)
            self.rule_fields[vehicle] = (base, km, per)
            fare_controls += [ui.vehicle_chip(vehicle), ft.Row([base, km, per], spacing=8)]

        return self.scroll_column([
            ui.page_title("Settings", "Budget, fares and data"),
            ui.card(ft.Column([
                ui.section_label("Fare Allowance Wallet"),
                ft.Text("Saving a new amount resets the wallet and starts a new budget period.",
                        size=FontSize.CAPTION, color=Palette.MUTED),
                self.balance_box,
                ui.primary_button("Save / reset balance", on_click=self._save_balance)], spacing=10)),
            ui.card(ft.Column([
                ui.section_label("Fare matrix"),
                ft.Text("Sample baseline values. Update them to match the current LTFRB / city rates.",
                        size=FontSize.CAPTION, color=Palette.MUTED),
                *fare_controls,
                ui.primary_button("Save fare matrix", on_click=self._save_fares)], spacing=10)),
            ui.card(ft.Column([
                ui.section_label("Export data"),
                ft.Text("Creates CSV files of your trip logs and savings history on this device.",
                        size=FontSize.CAPTION, color=Palette.MUTED),
                ui.soft_button("Export to CSV", ft.Icons.DOWNLOAD, self._export)], spacing=10)),
            self._report_card(),
            ft.Text(f"{APP_NAME} v{APP_VERSION}", size=FontSize.CAPTION, color=Palette.MUTED,
                    text_align=ft.TextAlign.CENTER),
        ])

    def _save_balance(self, _e) -> None:
        value = to_float(self.balance.value)
        if value <= 0:
            ui.notify(self.page, "Enter an amount greater than 0.", Palette.DANGER)
            return
        self.services.wallet.set_starting_balance(value)
        ui.notify(self.page, f"Wallet set to {money(value)}.", Palette.SUCCESS)

    def _save_fares(self, _e) -> None:
        for vehicle, (base, km, per) in self.rule_fields.items():
            b, k, p = to_float(base.value), to_float(km.value), to_float(per.value)
            if b <= 0 or k <= 0 or p < 0:
                ui.notify(self.page, f"Check the values for {vehicle}.", Palette.DANGER)
                return
            self.services.fares.update_rule(FareRule(vehicle, b, k, p))
        ui.notify(self.page, "Fare matrix updated.", Palette.SUCCESS)

    def _report_card(self) -> ft.Control:
        buttons: list[ft.Control] = [ui.soft_button("Save report file", ft.Icons.BUG_REPORT, self._export_log)]
        if SUPPORT_EMAIL:
            buttons.append(ui.primary_button("Email developer", ft.Icons.EMAIL, self._email_report))
        return ui.card(ft.Column([
            ui.section_label("Report a problem"),
            ft.Text("PisoPasa works offline, so it cannot send anything by itself. If something went wrong, "
                    "this creates a small report (app version, phone/PC info and recent error messages, "
                    "never your trips or money) that you can send to the developer. The developer uses it "
                    "to find and fix the bug.", size=FontSize.CAPTION, color=Palette.MUTED),
            ft.Row(buttons, wrap=True, spacing=8)], spacing=10))

    def _export_log(self, _e) -> None:
        path = self.services.export.export_log()
        ui.notify(self.page, f"Report saved: {path}. Send this file to the developer.", Palette.SUCCESS)

    async def _email_report(self, _e) -> None:
        text = self.services.export.report_text(15)[:1500]
        url = f"mailto:{SUPPORT_EMAIL}?subject={quote(APP_NAME + ' problem report')}&body={quote(text)}"
        try:
            await self.app.url_launcher.launch_url(url)
        except Exception:
            path = self.services.export.export_log()
            ui.notify(self.page, f"Could not open email. Report saved: {path}", Palette.WARNING)

    def _export(self, _e) -> None:
        files = self.services.export.export_all()
        ui.notify(self.page, f"Saved: {files[0].parent}", Palette.SUCCESS)
