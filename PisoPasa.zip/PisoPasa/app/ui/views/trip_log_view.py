from __future__ import annotations

import flet as ft

from app.models.entities import Leg, RouteOption
from app.services.trip_service import ValidationError
from app.ui import components as ui
from app.ui.formatters import money
from app.ui.theme import FontSize, Palette, Spacing
from app.ui.views.base_view import BaseView


class TripLogView(BaseView):
    title = "Log Trip"

    def build(self) -> ft.Control:
        self.origin = ui.text_field("Origin (e.g. Palo)", on_change=lambda _e: self._suggest())
        self.destination = ui.text_field("Destination (e.g. Tacloban)", on_change=lambda _e: self._suggest())
        self.legs_column = ft.Column(spacing=Spacing.SM)
        self.total_text = ft.Text("₱0.00", size=FontSize.HERO - 6, weight=ft.FontWeight.W_900,
                                  color=Palette.ON_DARK)
        self.editors: list[ui.LegEditor] = []
        self.suggest_column = ft.Column(spacing=Spacing.SM)
        self.banner = ft.Container(visible=False)
        self.save_fav = ft.Switch(label="Save as a favorite route", value=False, active_color=Palette.GREEN)
        self.fav_name = ui.text_field("Favorite name (e.g. Palo to Tacloban)")

        self.baseline: float | None = None
        self.chosen_label = ""
        self.chosen_source = ""
        self.original_legs: list[Leg] = []

        repeat = self.services.trips.get(self.params["repeat_trip_id"]) if self.params.get("repeat_trip_id") else None
        if repeat:
            self.origin.value, self.destination.value = repeat.origin, repeat.destination
            for leg in repeat.legs:
                self._new_editor(Leg(leg.vehicle, leg.distance_km, leg.fare))
        else:
            self._add_leg()
        self._suggest()
        return self.scroll_column([
            ui.page_title("Log a trip", "Add each hop; the total is computed for you"),
            ui.info_card("How it works",
                         "Type where you are going and what you pay for each hop. If you paid less for the same trip "
                         "before, or a cheaper vehicle exists in your fare matrix, a “Choose this route” card "
                         "appears under the hops and tells you exactly what changes. Pick it and the "
                         "difference is saved as your savings."),
            ui.card(ft.Column([
                ft.Row([ui.icon_chip(ft.Icons.ROUTE, Palette.GREEN),
                        ft.Text("Where to?", weight=ft.FontWeight.W_700, color=Palette.INK)], spacing=10),
                self.origin, self.destination], spacing=Spacing.SM)),
            ui.section_label("Hops"),
            self.legs_column,
            ui.soft_button("Add another hop", ft.Icons.ADD, lambda _e: self._add_leg(update=True)),
            self.banner,
            ui.section_label("Cheaper routes"),
            self.suggest_column,
            ui.hero_card(ft.Column([
                ft.Text("Trip total", size=FontSize.CAPTION, color=Palette.ON_DARK_MUTED),
                self.total_text], spacing=0)),
            ui.card(ft.Column([self.save_fav, self.fav_name], spacing=Spacing.SM)),
            ui.primary_button("Save trip", ft.Icons.CHECK, self._save),
        ])

    def _new_editor(self, leg: Leg | None = None) -> ui.LegEditor:
        editor = ui.LegEditor(self.services.calculator.estimate, self._remove_leg, self._recalc,
                              leg=leg, number=len(self.editors) + 1)
        self.editors.append(editor)
        self.legs_column.controls.append(editor.view)
        return editor

    def _add_leg(self, update: bool = False) -> None:
        self._new_editor()
        if update:
            self.legs_column.update()

    def _set_legs(self, legs: list[Leg]) -> None:
        self.editors.clear()
        self.legs_column.controls.clear()
        for leg in legs:
            self._new_editor(Leg(leg.vehicle, leg.distance_km, leg.fare))
        if ui.mounted(self.legs_column):
            self.legs_column.update()
        self._recalc()

    def _remove_leg(self, editor: ui.LegEditor) -> None:
        if len(self.editors) == 1:
            ui.notify(self.page, "A trip needs at least one hop.", Palette.WARNING)
            return
        self.editors.remove(editor)
        self.legs_column.controls.remove(editor.view)
        self.legs_column.update()
        self._recalc()

    def _current_legs(self) -> list[Leg]:
        return [e.to_leg() for e in self.editors]

    def _recalc(self) -> None:
        total = sum(l.fare for l in self._current_legs())
        self.total_text.value = money(total)
        if ui.mounted(self.total_text):
            self.total_text.update()
        self._suggest()

    def _suggest(self) -> None:
        legs = self._current_legs()
        total = round(sum(l.fare for l in legs), 2)
        origin, destination = self.origin.value or "", self.destination.value or ""
        if total <= 0:
            cards: list[ft.Control] = [ft.Text(
                "Enter the origin, destination and the fare of each hop. Cheaper options will show here.",
                size=FontSize.CAPTION, color=Palette.MUTED)]
        else:
            options = self.services.finder.suggest(origin, destination, legs)
            if options:
                cards = [ui.route_option_card(o, legs, total, lambda _e, opt=o: self._choose(opt))
                         for o in options]
            else:
                cards = [ft.Text("✓ No cheaper route found. This is the cheapest one we know for this trip.",
                                 size=FontSize.CAPTION, color=Palette.GREEN_DARK)]
        self.suggest_column.controls = cards
        if ui.mounted(self.suggest_column):
            self.suggest_column.update()

    def _choose(self, option: RouteOption) -> None:
        if self.baseline is None:
            self.original_legs = self._current_legs()
            self.baseline = round(sum(l.fare for l in self.original_legs), 2)
        self.chosen_label = option.label
        self.chosen_source = option.source
        self._set_legs(option.legs)
        self._show_banner()
        ui.notify(self.page, f"Cheaper route applied. You save {money(option.savings)}.", Palette.GREEN)

    def _show_banner(self) -> None:
        if self.baseline is None:
            self.banner.visible = False
        else:
            new_total = round(sum(l.fare for l in self._current_legs()), 2)
            self.banner.visible = True
            self.banner.content = ft.Container(
                bgcolor=Palette.GREEN_SOFT, padding=ft.Padding.all(Spacing.MD),
                border_radius=ft.BorderRadius.all(18),
                content=ft.Row([
                    ft.Icon(ft.Icons.CHECK_CIRCLE, color=Palette.GREEN_DARK),
                    ft.Text(f"Using a cheaper route. You will save {money(self.baseline - new_total)} "
                            f"compared with your first entry.", size=FontSize.CAPTION, color=Palette.INK,
                            expand=True),
                    ft.TextButton("Undo", on_click=self._undo)], spacing=10))
        if ui.mounted(self.banner):
            self.banner.update()

    def _undo(self, _e) -> None:
        if self.baseline is None:
            return
        legs = self.original_legs
        self.baseline, self.chosen_label, self.chosen_source, self.original_legs = None, "", "", []
        self._set_legs(legs)
        self._show_banner()

    def _save(self, _e) -> None:
        legs = self._current_legs()
        try:
            trip = self.services.trips.log_trip(self.origin.value or "", self.destination.value or "", legs)
            if self.save_fav.value:
                self.services.favorites.save(self.fav_name.value or "", trip.origin, trip.destination, legs)
        except ValidationError as err:
            ui.notify(self.page, str(err), Palette.DANGER)
            return

        saved, reached = 0.0, None
        if self.baseline is not None and self.baseline > trip.total:
            saved, reached = self.services.savings.record_switch(
                trip, self.baseline, self.chosen_label, self.original_legs, self.chosen_source)
        self.app.after_trip_logged(trip, saved=saved, reached=reached)
