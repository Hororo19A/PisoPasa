from __future__ import annotations

from typing import TYPE_CHECKING

import flet as ft

from app.ui.theme import Spacing

if TYPE_CHECKING:
    from app.pisopasa_app import PisoPasaApp


class BaseView:

    title = ""

    def __init__(self, app: "PisoPasaApp", **params) -> None:
        self.app = app
        self.services = app.services
        self.page = app.page
        self.params = params

    def build(self) -> ft.Control:
        raise NotImplementedError

    def scroll_column(self, controls: list[ft.Control]) -> ft.Column:
        return ft.Column(controls, scroll=ft.ScrollMode.AUTO, expand=True, spacing=Spacing.MD,
                         horizontal_alignment=ft.CrossAxisAlignment.STRETCH)

    def refresh(self) -> None:
        self.app.show(type(self), **self.params)
