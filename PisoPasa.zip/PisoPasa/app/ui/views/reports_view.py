from __future__ import annotations

from datetime import date

import flet as ft

from app.ui import components as ui
from app.ui.formatters import money
from app.ui.theme import Palette
from app.ui.views.base_view import BaseView


class ReportsView(BaseView):
    title = "Reports"

    def build(self) -> ft.Control:
        period = self.params.get("period", "weekly")
        data = self.services.reports.weekly() if period == "weekly" else self.services.reports.monthly()
        daily = [(self._day_label(d), v) for d, v in data["daily"]]

        return self.scroll_column([
            ui.page_title("Reports", "Where your fare money goes"),
            ui.pill_tabs([("weekly", "Weekly"), ("monthly", "Monthly")], period,
                         lambda k: self.app.show(ReportsView, period=k)),
            ft.Row([ui.stat_tile("Fare spent", money(data["total_fare"]), Palette.GREEN, ft.Icons.PAYMENTS),
                    ui.stat_tile("Saved", money(data["total_savings"]), Palette.GREEN, ft.Icons.SAVINGS)]),
            ui.card(ft.Column([ui.section_label("Spending per day"), ui.column_chart(daily)], spacing=12)),
            ui.card(ft.Column([ui.section_label("By vehicle type"),
                               ui.donut(data["by_vehicle"], "Total", money(data["total_fare"]),
                                        use_vehicle_colors=True)], spacing=12)),
            self._routes(data["by_route"]),
        ])

    @staticmethod
    def _day_label(iso: str) -> str:
        try:
            d = date.fromisoformat(iso)
            return d.strftime("%b %d").replace(" 0", " ")
        except ValueError:
            return iso

    @staticmethod
    def _routes(rows: list[tuple[str, float]]) -> ft.Control:
        if not rows:
            return ui.card(ft.Column([ui.section_label("Top routes"), ui.empty_state("No data in this period.")]))
        top = max(v for _, v in rows)
        return ui.card(ft.Column([ui.section_label("Top routes"),
                                  *[ui.bar_row(l, v, top, Palette.GREEN) for l, v in rows]], spacing=12))
