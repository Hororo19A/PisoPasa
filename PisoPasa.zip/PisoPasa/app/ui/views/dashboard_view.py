from __future__ import annotations

import flet as ft

from datetime import datetime

from app.ui import components as ui
from app.ui.greeting import clock_line, greeting_for
from app.ui.formatters import money, pretty_date, to_float
from app.ui.theme import WALLET_LEVELS, FontSize, Palette, Spacing
from app.ui.views.base_view import BaseView

PERIODS = [("today", "Today", 1), ("week", "Week", 7), ("month", "Month", 30), ("year", "Year", 365)]


class DashboardView(BaseView):
    title = "Home"

    def build(self) -> ft.Control:
        period = self.params.get("period", "week")
        days = next(d for k, _, d in PERIODS if k == period)
        label = next(l for k, l, _ in PERIODS if k == period)
        data = self.services.reports.report(days)
        savings = self.services.savings

        return self.scroll_column([
            self._header(),
            self._wallet_hero(),
            ui.pill_tabs([(k, l) for k, l, _ in PERIODS], period,
                         lambda k: self.app.show(DashboardView, period=k)),
            ui.card(ui.donut(data["by_vehicle"], f"Spent ({label.lower()})", money(data["total_fare"]),
                             use_vehicle_colors=True)),
            ft.Row([ui.stat_tile("Saved so far", money(savings.total()), Palette.GREEN, ft.Icons.SAVINGS),
                    ui.stat_tile("Trips logged", str(len(self.services.trips.recent(1000))),
                                 Palette.GREEN_DARK, ft.Icons.CONFIRMATION_NUMBER)]),
            self._goal_card(),
            ui.action_strip([
                ui.action_pill("Log trip", ft.Icons.ADD_ROAD, lambda _e: self.app.navigate("log")),
                ui.action_pill("Favorites", ft.Icons.STAR_ROUNDED, lambda _e: self.app.navigate("favorites")),
                ui.action_pill("Reports", ft.Icons.INSIGHTS, lambda _e: self.app.navigate("reports")),
            ]),
            ui.section_label("Recent trips"),
            *self._recent(),
        ])

    def _header(self) -> ft.Control:
        now = datetime.now()
        self.greeting = ft.Text(greeting_for(now), size=FontSize.TITLE, weight=ft.FontWeight.W_800,
                                color=Palette.INK)
        self.clock = ft.Text(clock_line(now), size=FontSize.CAPTION, color=Palette.MUTED)
        self.app.live_header = (self.greeting, self.clock)
        return ft.Column([self.greeting, self.clock], spacing=2)

    def _wallet_hero(self) -> ft.Control:
        wallet = self.services.wallet.status()
        color, label = WALLET_LEVELS[wallet.level]
        header = ft.Row([ui.icon_chip(ft.Icons.ACCOUNT_BALANCE_WALLET, Palette.GREEN_LIGHT),
                         ft.Text("Fare wallet", color=Palette.ON_DARK, weight=ft.FontWeight.W_700,
                                 size=FontSize.SUBTITLE, expand=True),
                         ui.status_pill(label, color)], spacing=10)

        if wallet.level == "unset":
            amount_box, amount = ui.stacked_number_field(
                "Starting fare allowance (₱)", "e.g. 500", label_color=Palette.ON_DARK)

            def save(_e):
                value = to_float(amount.value)
                if value <= 0:
                    ui.notify(self.page, "Enter an amount greater than 0.", Palette.DANGER)
                    return
                self.services.wallet.set_starting_balance(value)
                self.refresh()

            return ui.hero_card(ft.Column([
                header,
                ft.Text("Set a starting budget and every logged fare is deducted automatically.",
                        size=FontSize.CAPTION, color=Palette.ON_DARK_MUTED),
                amount_box, ui.accent_button("Set budget", on_click=save)], spacing=Spacing.SM + 2))

        share = max(0.0, wallet.remaining / wallet.starting) if wallet.starting else 0.0
        return ui.hero_card(ft.Column([
            header,
            ft.Text(money(wallet.remaining), size=FontSize.HERO, weight=ft.FontWeight.W_900,
                    color=Palette.ON_DARK),
            ft.Text("remaining allowance", size=FontSize.CAPTION, color=Palette.ON_DARK_MUTED),
            ui.capsule_progress(share, color, Palette.TRACK_DARK, 12),
            ft.Row([ft.Text(f"{money(wallet.spent)} spent", size=FontSize.BODY, color=Palette.ON_DARK),
                    ft.Text(f"{money(wallet.starting)} budget", size=FontSize.BODY,
                            color=Palette.ON_DARK_MUTED)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        ], spacing=Spacing.SM))

    def _goal_card(self) -> ft.Control:
        goal = self.services.savings.active_goal()
        if not goal:
            return ui.card(ft.Row([
                ui.icon_chip(ft.Icons.FLAG, Palette.GREEN),
                ft.Column([ft.Text("No savings goal yet", weight=ft.FontWeight.W_700, color=Palette.INK),
                           ft.Text("Save toward something you want.", size=FontSize.CAPTION,
                                   color=Palette.MUTED)], spacing=2, expand=True),
                ui.soft_button("Set goal", on_click=lambda _e: self.app.navigate("savings"))], spacing=12))
        return ui.card(ui.progress_block(goal.label, goal.saved, goal.target, goal.progress))

    def _recent(self) -> list[ft.Control]:
        trips = self.services.trips.recent(3)
        if not trips:
            return [ui.empty_state("No trips yet. Tap “Log trip” to record your first one.")]
        out = []
        for t in trips:
            top = ft.Column([
                ft.Row([ft.Text(t.route_text, weight=ft.FontWeight.W_700, color=Palette.INK, expand=True),
                        ft.Text(money(t.total), weight=ft.FontWeight.W_900, size=FontSize.SUBTITLE,
                                color=Palette.INK)]),
                ft.Row([ui.vehicle_chip(l.vehicle) for l in t.legs], wrap=True, spacing=6, run_spacing=6),
            ], spacing=Spacing.SM)
            bottom = ft.Row([ft.Text(pretty_date(t.logged_at), size=FontSize.CAPTION, color=Palette.MUTED,
                                     expand=True),
                             ft.TextButton("Repeat trip", icon=ft.Icons.REPLAY,
                                           on_click=lambda _e, i=t.id: self.app.navigate("log", repeat_trip_id=i))])
            out.append(ui.ticket(top, bottom))
        return out
