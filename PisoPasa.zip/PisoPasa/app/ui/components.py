from __future__ import annotations

from typing import Callable

import flet as ft
import flet_charts as fch

from app.config import CURRENCY, VEHICLES
from app.models.entities import Leg
from app.ui.formatters import money, to_float
from app.ui.theme import (FontSize, Palette, Radius, Spacing, hero_gradient, soft_shadow,
                          sun_gradient, vehicle_color, vehicle_icon)

def mounted(control: ft.Control) -> bool:
    try:
        return control.page is not None
    except RuntimeError:
        return False


CHART_COLORS = [Palette.GREEN, Palette.INK, Palette.GREEN_LIGHT, Palette.GREEN_DARK, Palette.GREY_GREEN]


def page_title(text: str, subtitle: str | None = None) -> ft.Control:
    items: list[ft.Control] = [ft.Text(text, size=FontSize.TITLE, weight=ft.FontWeight.W_800,
                                       color=Palette.INK)]
    if subtitle:
        items.append(ft.Text(subtitle, size=FontSize.CAPTION, color=Palette.MUTED))
    return ft.Column(items, spacing=2)


def section_label(text: str, action: ft.Control | None = None) -> ft.Control:
    row: list[ft.Control] = [ft.Text(text, size=FontSize.SUBTITLE, weight=ft.FontWeight.W_700,
                                     color=Palette.INK, expand=True)]
    if action:
        row.append(action)
    return ft.Row(row)


def empty_state(message: str) -> ft.Control:
    return ft.Container(
        content=ft.Text(message, color=Palette.MUTED, text_align=ft.TextAlign.CENTER),
        padding=ft.Padding.all(Spacing.LG), alignment=ft.Alignment.CENTER)


def logo_mark(logo: bytes | None, size: int = 36) -> ft.Control:
    radius = ft.BorderRadius.all(size * 0.32)
    if logo:
        return ft.Container(
            width=size, height=size, border_radius=radius, bgcolor=Palette.SURFACE,
            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            content=ft.Image(src=logo, width=size, height=size, fit=ft.BoxFit.COVER))
    return ft.Container(
        width=size, height=size, border_radius=radius, gradient=sun_gradient(),
        alignment=ft.Alignment.CENTER,
        content=ft.Text(CURRENCY, size=size * 0.55, weight=ft.FontWeight.W_900, color=Palette.INK))


def brand_bar_title(name: str, logo: bytes | None) -> ft.Control:
    return ft.Row([logo_mark(logo, 34),
                   ft.Text(name, size=20, weight=ft.FontWeight.W_900, color=Palette.INK)],
                  spacing=10)


def _stretch(content: ft.Control) -> ft.Control:
    if isinstance(content, ft.Column) and content.horizontal_alignment in (None, ft.CrossAxisAlignment.START):
        content.horizontal_alignment = ft.CrossAxisAlignment.STRETCH
    return content


def card(content: ft.Control, bgcolor: str = Palette.SURFACE, padding: int = Spacing.MD) -> ft.Container:
    content = _stretch(content)
    return ft.Container(content=content, bgcolor=bgcolor, padding=ft.Padding.all(padding),
                        border_radius=ft.BorderRadius.all(Radius.CARD), shadow=soft_shadow())


def tile(content: ft.Control, expand: bool | int | None = None) -> ft.Container:
    content = _stretch(content)
    return ft.Container(content=content, bgcolor=Palette.TILE, expand=expand,
                        padding=ft.Padding.all(Spacing.MD),
                        border_radius=ft.BorderRadius.all(Radius.TILE),
                        border=ft.Border.all(1, Palette.LINE))


def hero_card(content: ft.Control) -> ft.Container:
    glow = ft.Container(width=170, height=170, right=-60, top=-70,
                        border_radius=ft.BorderRadius.all(85), bgcolor="#2216A34A")
    body = ft.Container(content=content, padding=ft.Padding.all(Spacing.MD + 4))
    return ft.Container(
        content=ft.Stack([glow, body]), gradient=hero_gradient(),
        border_radius=ft.BorderRadius.all(Radius.CARD), shadow=soft_shadow(),
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS)


def ticket(top: ft.Control, bottom: ft.Control) -> ft.Container:
    hole_l = ft.Container(width=14, height=28, bgcolor=Palette.PAPER, border_radius=ft.BorderRadius(
        top_left=0, top_right=14, bottom_left=0, bottom_right=14))
    hole_r = ft.Container(width=14, height=28, bgcolor=Palette.PAPER, border_radius=ft.BorderRadius(
        top_left=14, top_right=0, bottom_left=14, bottom_right=0))
    dashes = ft.Row([ft.Container(width=7, height=2, bgcolor=Palette.LINE) for _ in range(22)],
                    alignment=ft.MainAxisAlignment.SPACE_EVENLY, expand=True)
    tear = ft.Row([hole_l, dashes, hole_r], spacing=0, vertical_alignment=ft.CrossAxisAlignment.CENTER)
    pad = ft.Padding.symmetric(horizontal=Spacing.MD, vertical=Spacing.SM + 2)
    return ft.Container(
        content=ft.Column([ft.Container(top, padding=pad), tear, ft.Container(bottom, padding=pad)],
                          spacing=0),
        bgcolor=Palette.SURFACE, border_radius=ft.BorderRadius.all(Radius.CARD),
        shadow=soft_shadow(), clip_behavior=ft.ClipBehavior.ANTI_ALIAS)


def icon_chip(icon: str, color: str, size: int = 38) -> ft.Control:
    return ft.Container(width=size, height=size, alignment=ft.Alignment.CENTER,
                        bgcolor=ft.Colors.with_opacity(0.16, color),
                        border_radius=ft.BorderRadius.all(size * 0.34),
                        content=ft.Icon(icon, color=color, size=size * 0.55))


def vehicle_chip(vehicle: str) -> ft.Control:
    color = vehicle_color(vehicle)
    chip = ft.Container(
        padding=ft.Padding.symmetric(horizontal=10, vertical=5),
        bgcolor=Palette.GREEN_SOFT, border_radius=ft.BorderRadius.all(20),
        content=ft.Row([ft.Container(width=8, height=8, bgcolor=color, border_radius=ft.BorderRadius.all(4)),
                        ft.Icon(vehicle_icon(vehicle), size=14, color=Palette.INK),
                        ft.Text(vehicle, size=FontSize.CAPTION, weight=ft.FontWeight.W_600,
                                color=Palette.INK)], spacing=5, tight=True))
    return ft.Row([chip], tight=True)


def status_pill(text: str, color: str) -> ft.Control:
    return ft.Container(
        content=ft.Text(text, size=FontSize.CAPTION, weight=ft.FontWeight.W_700, color=Palette.ON_DARK),
        bgcolor=color, padding=ft.Padding.symmetric(horizontal=12, vertical=5),
        border_radius=ft.BorderRadius.all(20))


def info_card(title: str, text: str, icon: str = ft.Icons.INFO_OUTLINE) -> ft.Control:
    return ft.Container(
        bgcolor=Palette.GREEN_SOFT, padding=ft.Padding.all(Spacing.MD),
        border_radius=ft.BorderRadius.all(Radius.TILE),
        content=ft.Row([
            ft.Icon(icon, color=Palette.GREEN_DARK, size=22),
            ft.Column([ft.Text(title, weight=ft.FontWeight.W_800, color=Palette.GREEN_DARK,
                               size=FontSize.BODY),
                       ft.Text(text, size=FontSize.CAPTION, color=Palette.INK)],
                      spacing=3, expand=True)],
            vertical_alignment=ft.CrossAxisAlignment.START, spacing=12))


def route_option_card(option, current_legs: list[Leg], current_total: float,
                      on_choose: Callable) -> ft.Control:
    from_history = option.source == "history"
    source = ft.Container(
        content=ft.Text("From your trip history" if from_history else "From your fare matrix", size=11,
                        weight=ft.FontWeight.W_800, color=Palette.ON_DARK),
        bgcolor=Palette.INK if from_history else Palette.GREEN_DARK,
        padding=ft.Padding.symmetric(horizontal=10, vertical=4), border_radius=ft.BorderRadius.all(20))
    saves = ft.Container(
        content=ft.Text(f"Save {money(option.savings)}", size=FontSize.CAPTION,
                        weight=ft.FontWeight.W_800, color=Palette.INK),
        bgcolor=Palette.GREEN_SOFT, padding=ft.Padding.symmetric(horizontal=12, vertical=5),
        border_radius=ft.BorderRadius.all(20))

    lines: list[ft.Control] = []
    same_shape = len(option.legs) == len(current_legs)
    for i, new in enumerate(option.legs):
        if same_shape and (current_legs[i].vehicle != new.vehicle or current_legs[i].fare != new.fare):
            old = current_legs[i]
            text = (f"Hop {i + 1}: {old.vehicle} {money(old.fare)}  →  {new.vehicle} {money(new.fare)}")
        else:
            text = f"Hop {i + 1}: {new.vehicle} {money(new.fare)}"
        lines.append(ft.Text(text, size=FontSize.CAPTION, color=Palette.INK))

    return ft.Container(
        bgcolor=Palette.SURFACE, padding=ft.Padding.all(Spacing.MD), shadow=soft_shadow(),
        border_radius=ft.BorderRadius.all(Radius.TILE), border=ft.Border.all(1.5, Palette.GREEN),
        content=ft.Column([
            ft.Row([source, ft.Container(expand=True), saves]),
            ft.Text(option.note, size=FontSize.BODY, weight=ft.FontWeight.W_700, color=Palette.INK),
            ft.Column(lines, spacing=3),
            ft.Row([ft.Text(money(option.total), size=FontSize.SUBTITLE + 2, weight=ft.FontWeight.W_900,
                            color=Palette.INK),
                    ft.Text(f"instead of {money(current_total)}", size=FontSize.CAPTION, color=Palette.MUTED)],
                   spacing=8, vertical_alignment=ft.CrossAxisAlignment.END),
            accent_button("Choose this route", ft.Icons.CHECK_CIRCLE, on_choose),
        ], spacing=Spacing.SM))


def stat_tile(label: str, value: str, color: str = Palette.GREEN, icon: str | None = None) -> ft.Control:
    head: list[ft.Control] = []
    if icon:
        head.append(icon_chip(icon, color, 34))
    return ft.Container(
        expand=True, bgcolor=Palette.SURFACE, padding=ft.Padding.all(Spacing.MD),
        border_radius=ft.BorderRadius.all(Radius.TILE), shadow=soft_shadow(),
        content=ft.Column([*head,
                           ft.Text(label, size=FontSize.CAPTION, color=Palette.MUTED),
                           ft.Text(value, size=FontSize.SUBTITLE + 2, weight=ft.FontWeight.W_800,
                                   color=Palette.INK)], spacing=4))


def capsule_progress(share: float, color: str = Palette.GREEN, track: str = Palette.LINE,
                     height: int = 10) -> ft.Control:
    filled = max(0, min(100, round(share * 100)))
    parts: list[ft.Control] = []
    if filled:
        parts.append(ft.Container(expand=filled, bgcolor=color,
                                  border_radius=ft.BorderRadius.all(height)))
    if filled < 100:
        parts.append(ft.Container(expand=100 - filled))
    return ft.Container(content=ft.Row(parts, spacing=0), height=height, bgcolor=track,
                        border_radius=ft.BorderRadius.all(height))


def progress_block(label: str, saved: float, target: float, progress: float) -> ft.Control:
    return ft.Column([
        ft.Row([ft.Text(label, weight=ft.FontWeight.W_700, color=Palette.INK, expand=True),
                ft.Text(f"{progress * 100:.0f}%", weight=ft.FontWeight.W_800, color=Palette.GREEN)]),
        capsule_progress(progress, Palette.GREEN, Palette.GREEN_SOFT, 12),
        ft.Text(f"{money(saved)} of {money(target)}", size=FontSize.CAPTION, color=Palette.MUTED),
    ], spacing=Spacing.SM)


def bar_row(label: str, value: float, max_value: float, color: str = Palette.GREEN) -> ft.Control:
    share = (value / max_value) if max_value > 0 else 0
    return ft.Column([
        ft.Row([ft.Text(label, size=FontSize.BODY, expand=True, overflow=ft.TextOverflow.ELLIPSIS,
                        color=Palette.INK),
                ft.Text(money(value), size=FontSize.BODY, weight=ft.FontWeight.W_700,
                        color=Palette.INK)]),
        capsule_progress(share, color, Palette.TILE, 8),
    ], spacing=4)


def column_chart(rows: list[tuple[str, float]], height: int = 130) -> ft.Control:
    if not rows:
        return empty_state("No data in this period.")
    top = max(v for _, v in rows) or 1
    bars: list[ft.Control] = []
    for label, value in rows:
        is_top = value == top
        bar = ft.Container(
            width=34, height=max(10, int(value / top * height)),
            border_radius=ft.BorderRadius.all(14),
            gradient=sun_gradient() if is_top else None,
            bgcolor=None if is_top else Palette.GREEN_SOFT)
        caption = ft.Text(f"{CURRENCY}{value:.0f}" if is_top else " ", size=11,
                          weight=ft.FontWeight.W_800, color=Palette.GREEN)
        bars.append(ft.Column([caption, bar, ft.Text(label, size=11, color=Palette.MUTED)],
                              spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                              alignment=ft.MainAxisAlignment.END))
    return ft.Container(
        height=height + 56,
        content=ft.Row(bars, spacing=10, scroll=ft.ScrollMode.AUTO,
                       vertical_alignment=ft.CrossAxisAlignment.END))


def donut(rows: list[tuple[str, float]], center_label: str, center_value: str,
          size: int = 210, use_vehicle_colors: bool = False) -> ft.Control:
    def color_of(i: int, name: str) -> str:
        return vehicle_color(name) if use_vehicle_colors else CHART_COLORS[i % len(CHART_COLORS)]

    if rows:
        sections = [fch.PieChartSection(value=v, color=color_of(i, n), radius=28, title="")
                    for i, (n, v) in enumerate(rows)]
    else:
        sections = [fch.PieChartSection(value=1, color=Palette.LINE, radius=28, title="")]
    chart = fch.PieChart(sections=sections, center_space_radius=(size - 56) / 2 - 14,
                         sections_space=3, left=0, top=0, right=0, bottom=0)
    middle = ft.Container(
        left=0, top=0, right=0, bottom=0, alignment=ft.Alignment.CENTER,
        content=ft.Column([ft.Text(center_label, size=FontSize.CAPTION, color=Palette.MUTED),
                           ft.Text(center_value, size=26, weight=ft.FontWeight.W_900, color=Palette.INK)],
                          spacing=0, tight=True, horizontal_alignment=ft.CrossAxisAlignment.CENTER))
    legend = ft.Row(
        [ft.Row([ft.Container(width=10, height=10, bgcolor=color_of(i, n),
                              border_radius=ft.BorderRadius.all(5)),
                 ft.Text(f"{n} {money(v)}", size=FontSize.CAPTION, color=Palette.INK)], spacing=6, tight=True)
         for i, (n, v) in enumerate(rows)],
        wrap=True, spacing=14, run_spacing=6, alignment=ft.MainAxisAlignment.CENTER)
    return ft.Column([ft.Container(ft.Stack([chart, middle], width=size, height=size),
                                   alignment=ft.Alignment.CENTER), legend],
                     spacing=Spacing.SM, horizontal_alignment=ft.CrossAxisAlignment.CENTER)


def pill_tabs(options: list[tuple[str, str]], selected: str,
              on_select: Callable[[str], None]) -> ft.Control:
    pills = []
    for key, label in options:
        active = key == selected
        pills.append(ft.Container(
            expand=True, alignment=ft.Alignment.CENTER,
            padding=ft.Padding.symmetric(vertical=10),
            bgcolor=Palette.INK if active else None,
            border_radius=ft.BorderRadius.all(Radius.PILL),
            on_click=lambda _e, k=key: on_select(k),
            content=ft.Text(label, size=FontSize.BODY, weight=ft.FontWeight.W_700 if active else ft.FontWeight.W_500,
                            color=Palette.ON_DARK if active else Palette.MUTED)))
    return ft.Container(content=ft.Row(pills, spacing=2), bgcolor="#E3EBE6", padding=ft.Padding.all(4),
                        border_radius=ft.BorderRadius.all(Radius.PILL))


def primary_button(text: str, icon: str | None = None, on_click: Callable | None = None) -> ft.Button:
    return ft.Button(content=text, icon=icon, on_click=on_click, style=ft.ButtonStyle(
        bgcolor=Palette.INK, color=Palette.ON_DARK, shape=ft.RoundedRectangleBorder(radius=Radius.PILL),
        padding=ft.Padding.symmetric(horizontal=26, vertical=16)))


def accent_button(text: str, icon: str | None = None, on_click: Callable | None = None) -> ft.Button:
    return ft.Button(content=text, icon=icon, on_click=on_click, style=ft.ButtonStyle(
        bgcolor=Palette.GREEN, color=Palette.ON_DARK, shape=ft.RoundedRectangleBorder(radius=Radius.PILL),
        padding=ft.Padding.symmetric(horizontal=26, vertical=16)))


def soft_button(text: str, icon: str | None = None, on_click: Callable | None = None) -> ft.Button:
    return ft.Button(content=text, icon=icon, on_click=on_click, style=ft.ButtonStyle(
        bgcolor=Palette.TILE, color=Palette.INK, shape=ft.RoundedRectangleBorder(radius=Radius.PILL),
        side=ft.BorderSide(1, Palette.LINE), padding=ft.Padding.symmetric(horizontal=22, vertical=14)))


def action_pill(text: str, icon: str, on_click: Callable) -> ft.Control:
    return ft.Container(
        on_click=on_click, bgcolor=Palette.INK_SOFT, padding=ft.Padding.symmetric(horizontal=16, vertical=11),
        border_radius=ft.BorderRadius.all(Radius.PILL), border=ft.Border.all(1, Palette.TRACK_DARK),
        content=ft.Row([ft.Icon(icon, color=Palette.ON_DARK, size=18),
                        ft.Text(text, color=Palette.ON_DARK, weight=ft.FontWeight.W_600, size=FontSize.BODY)],
                       spacing=8, tight=True))


def action_strip(pills: list[ft.Control]) -> ft.Control:
    return ft.Container(content=ft.Row(pills, scroll=ft.ScrollMode.AUTO, spacing=10),
                        bgcolor=Palette.INK, padding=ft.Padding.all(Spacing.MD),
                        border_radius=ft.BorderRadius.all(Radius.CARD))


_FIELD_BORDER = ft.OutlineInputBorder(border_radius=ft.BorderRadius.all(16),
                                      side=ft.BorderSide(1, Palette.LINE))
_FIELD_PAD = ft.Padding.symmetric(horizontal=14, vertical=12)


def text_field(label: str, value: str = "", number: bool = False, on_change: Callable | None = None,
               expand: bool | int | None = None, width: int | None = None) -> ft.TextField:
    return ft.TextField(
        label=label, value=value, on_change=on_change, expand=expand, width=width, dense=True,
        keyboard_type=ft.KeyboardType.NUMBER if number else ft.KeyboardType.TEXT,
        filled=True, fill_color=Palette.SURFACE, border=_FIELD_BORDER, content_padding=_FIELD_PAD,
        focused_border_color=Palette.GREEN, cursor_color=Palette.GREEN, color=Palette.INK,
        text_style=ft.TextStyle(color=Palette.INK, size=15, weight=ft.FontWeight.W_500),
        label_style=ft.TextStyle(color=Palette.MUTED),
        hint_style=ft.TextStyle(color=Palette.MUTED))


def number_field(label: str, value: str = "", on_change: Callable | None = None,
                 expand: bool | int | None = None, width: int | None = None) -> ft.TextField:
    return text_field(label, value, True, on_change, expand, width)


def stacked_number_field(label: str, hint: str = "", value: str = "",
                         label_color: str = Palette.MUTED) -> tuple[ft.Control, ft.TextField]:
    field = text_field("", value, number=True)
    field.label = None
    field.hint_text = hint
    return ft.Column([ft.Text(label, size=FontSize.CAPTION, weight=ft.FontWeight.W_600,
                              color=label_color), field], spacing=6, tight=True), field


def vehicle_dropdown(value: str, on_select: Callable | None = None) -> ft.Dropdown:
    return ft.Dropdown(
        label="Vehicle", value=value, dense=True, expand=True, filled=True, fill_color=Palette.SURFACE,
        border=_FIELD_BORDER, content_padding=_FIELD_PAD, on_select=on_select,
        text_style=ft.TextStyle(color=Palette.INK, size=15, weight=ft.FontWeight.W_500),
        label_style=ft.TextStyle(color=Palette.MUTED),
        options=[ft.DropdownOption(key=v, text=v, style=ft.ButtonStyle(color=Palette.INK))
                 for v in VEHICLES])


class AmountStepper:

    def __init__(self, start: float = 0.0, step: float = 50.0, on_change: Callable | None = None) -> None:
        self.value = float(start)
        self.step = step
        self.on_change = on_change
        self.text = ft.Text(self._fmt(), size=40, weight=ft.FontWeight.W_900, color=Palette.INK)
        self.view = ft.Row(
            [self._btn(ft.Icons.REMOVE, Palette.TILE, Palette.INK, -1), self.text,
             self._btn(ft.Icons.ADD, Palette.INK, Palette.ON_DARK, +1)],
            alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER, spacing=18)

    def _fmt(self) -> str:
        return f"{CURRENCY}{self.value:,.2f}"

    def _btn(self, icon: str, bg: str, fg: str, sign: int) -> ft.Control:
        return ft.IconButton(icon=icon, icon_color=fg, bgcolor=bg, on_click=lambda _e: self.bump(sign),
                             style=ft.ButtonStyle(shape=ft.CircleBorder()))

    def bump(self, sign: int) -> None:
        self.set(max(0.0, self.value + sign * self.step))

    def set(self, value: float) -> None:
        self.value = round(value, 2)
        self.text.value = self._fmt()
        if mounted(self.text):
            self.text.update()
        if self.on_change:
            self.on_change(self.value)


def notify(page: ft.Page, message: str, color: str = Palette.INK) -> None:
    page.show_dialog(ft.SnackBar(
        content=ft.Text(message, color=Palette.ON_DARK, weight=ft.FontWeight.W_600),
        bgcolor=color if color != Palette.GREEN else Palette.INK, behavior=ft.SnackBarBehavior.FLOATING,
        shape=ft.RoundedRectangleBorder(radius=18)))


def confirm_dialog(page: ft.Page, title: str, message: str, on_yes: Callable[[], None]) -> None:
    def yes(_e):
        page.pop_dialog()
        on_yes()

    page.show_dialog(ft.AlertDialog(
        modal=True, title=ft.Text(title, weight=ft.FontWeight.W_800), content=ft.Text(message),
        shape=ft.RoundedRectangleBorder(radius=24),
        actions=[ft.TextButton("Cancel", on_click=lambda _e: page.pop_dialog()),
                 ft.TextButton("Yes", on_click=yes)]))


class LegEditor:

    def __init__(self, estimate: Callable[[str, float], float],
                 on_remove: Callable[["LegEditor"], None],
                 on_change: Callable[[], None], leg: Leg | None = None, number: int = 1) -> None:
        self.estimate = estimate
        self.on_change = on_change
        self.vehicle = vehicle_dropdown(leg.vehicle if leg else VEHICLES[0], self._suggest)
        self.distance = number_field("Distance (km)", f"{leg.distance_km:g}" if leg else "", self._suggest, expand=1)
        self.fare = number_field("Fare paid (₱)", f"{leg.fare:.2f}" if leg else "", self._fare_changed, expand=1)
        self.view = tile(ft.Column([
            ft.Row([ft.Text(f"HOP {number}", size=11, weight=ft.FontWeight.W_800, color=Palette.GREEN, expand=True),
                    ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, icon_color=Palette.DANGER, icon_size=20,
                                  tooltip="Remove hop", on_click=lambda _e: on_remove(self))]),
            self.vehicle,
            ft.Row([self.distance, self.fare], spacing=Spacing.SM),
        ], spacing=Spacing.SM))

    def _suggest(self, _e=None) -> None:
        guess = self.estimate(self.vehicle.value or VEHICLES[0], to_float(self.distance.value))
        if guess > 0:
            self.fare.value = f"{guess:.2f}"
            if mounted(self.fare):
                self.fare.update()
        self.on_change()

    def _fare_changed(self, _e=None) -> None:
        self.on_change()

    def to_leg(self) -> Leg:
        return Leg(self.vehicle.value or VEHICLES[0], to_float(self.distance.value),
                   to_float(self.fare.value))
