from __future__ import annotations

import flet as ft

from app.config import BUS, JEEPNEY, MODERN_JEEP, TRICYCLE


class Palette:
    INK = "#0B0F0C"
    INK_SOFT = "#1B241E"
    TRACK_DARK = "#34403A"
    PAPER = "#F2F6F3"
    SURFACE = "#FFFFFF"
    TILE = "#F6F9F7"
    LINE = "#DDE6E0"
    MUTED = "#5F6B64"
    ON_DARK = "#FFFFFF"
    ON_DARK_MUTED = "#A7B5AC"
    GREEN = "#16A34A"
    GREEN_DARK = "#14532D"
    GREEN_LIGHT = "#4ADE80"
    GREEN_SOFT = "#DCF5E4"
    GREY_GREEN = "#8FA397"

    SUCCESS = GREEN
    BACKGROUND = PAPER
    WARNING = "#B7791F"
    DANGER = "#D93A4A"


class Radius:
    CARD = 26
    TILE = 18
    PILL = 40


class Spacing:
    SM = 8
    MD = 16
    LG = 24


class FontSize:
    CAPTION = 12
    BODY = 14
    SUBTITLE = 16
    TITLE = 22
    HERO = 38


VEHICLE_STYLE: dict[str, tuple[str, str]] = {
    JEEPNEY: (Palette.GREEN, ft.Icons.AIRPORT_SHUTTLE),
    MODERN_JEEP: (Palette.GREEN_LIGHT, ft.Icons.DIRECTIONS_CAR),
    BUS: (Palette.INK, ft.Icons.DIRECTIONS_BUS),
    TRICYCLE: (Palette.GREY_GREEN, ft.Icons.ELECTRIC_RICKSHAW),
}


def vehicle_color(vehicle: str) -> str:
    return VEHICLE_STYLE.get(vehicle, (Palette.GREEN, ft.Icons.ROUTE))[0]


def vehicle_icon(vehicle: str) -> str:
    return VEHICLE_STYLE.get(vehicle, (Palette.GREEN, ft.Icons.ROUTE))[1]


WALLET_LEVELS = {
    "ok": (Palette.GREEN, "On budget"),
    "low": (Palette.WARNING, "Almost out"),
    "over": (Palette.DANGER, "Over budget"),
    "unset": (Palette.GREY_GREEN, "No budget set"),
}


def hero_gradient() -> ft.LinearGradient:
    return ft.LinearGradient(begin=ft.Alignment.TOP_LEFT, end=ft.Alignment.BOTTOM_RIGHT,
                             colors=[Palette.INK_SOFT, Palette.INK])


def sun_gradient() -> ft.LinearGradient:
    return ft.LinearGradient(begin=ft.Alignment.TOP_CENTER, end=ft.Alignment.BOTTOM_CENTER,
                             colors=[Palette.GREEN_LIGHT, Palette.GREEN])


def soft_shadow() -> ft.BoxShadow:
    return ft.BoxShadow(blur_radius=18, spread_radius=0, color="#14000000", offset=ft.Offset(0, 6))


def build_theme() -> ft.Theme:
    return ft.Theme(
        use_material3=True,
        color_scheme=ft.ColorScheme(
            primary=Palette.GREEN, on_primary="#FFFFFF",
            secondary=Palette.INK, on_secondary="#FFFFFF",
            surface=Palette.SURFACE, on_surface=Palette.INK, on_surface_variant=Palette.MUTED,
            outline=Palette.LINE, error=Palette.DANGER),
    )
