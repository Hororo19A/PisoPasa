from __future__ import annotations

from datetime import datetime


def greeting_for(now: datetime) -> str:
    h = now.hour
    if 5 <= h < 11:
        return "Magandang umaga!"
    if 11 <= h < 13:
        return "Magandang tanghali!"
    if 13 <= h < 18:
        return "Magandang hapon!"
    return "Magandang gabi!"


def clock_line(now: datetime) -> str:
    return now.strftime("%A, %b ") + str(now.day) + now.strftime(" · ") + now.strftime("%I:%M %p").lstrip("0")
