from __future__ import annotations

from datetime import datetime

from app.config import CURRENCY


def money(amount: float) -> str:
    sign = "-" if amount < 0 else ""
    return f"{sign}{CURRENCY}{abs(amount):,.2f}"


def pretty_date(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%b %d, %I:%M %p")
    except ValueError:
        return iso


def to_float(text: str | None) -> float:
    try:
        return float((text or "").replace(",", "").strip())
    except ValueError:
        return 0.0
