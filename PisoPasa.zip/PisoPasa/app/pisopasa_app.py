from __future__ import annotations

import asyncio
from datetime import date, datetime

import flet as ft

from app.config import APP_NAME
from app.container import ServiceContainer
from app.models.entities import Trip
from app.ui import components as ui
from app.ui.theme import Palette, Spacing, build_theme
from app.logging_setup import get_logger
from app.ui.greeting import clock_line, greeting_for
from app.ui.views.base_view import BaseView
from app.ui.views.dashboard_view import DashboardView
from app.ui.views.favorites_view import FavoritesView
from app.ui.views.reports_view import ReportsView
from app.ui.views.savings_view import SavingsView
from app.ui.views.settings_view import SettingsView
from app.ui.views.trip_log_view import TripLogView
from app.ui.formatters import money

ROUTES: dict[str, type[BaseView]] = {
    "home": DashboardView,
    "log": TripLogView,
    "savings": SavingsView,
    "reports": ReportsView,
    "favorites": FavoritesView,
    "settings": SettingsView,
}
NAV_ORDER = ["home", "log", "savings", "reports"]


class PisoPasaApp:
    def __init__(self, page: ft.Page, services: ServiceContainer | None = None) -> None:
        self.page = page
        self.services = services or ServiceContainer()
        self.content = ft.Container(expand=True, padding=ft.Padding.all(Spacing.MD))
        self.log = get_logger()
        self.url_launcher = ft.UrlLauncher()
        self.live_header: tuple[ft.Text, ft.Text] | None = None
        self.current: tuple[type[BaseView], dict] | None = None
        self._logo_stamp = self.services.branding.logo_stamp()

    def start(self) -> None:
        page = self.page
        page.title = APP_NAME
        page.theme = build_theme()
        page.dark_theme = build_theme()
        page.theme_mode = ft.ThemeMode.LIGHT
        page.bgcolor = Palette.BACKGROUND
        page.padding = 0
        page.window.width = 400
        page.window.height = 800

        page.services.append(self.url_launcher)
        page.on_error = lambda e: self.log.error("Flet error: %s", getattr(e, "data", e))
        page.appbar = ft.AppBar(
            title=ui.brand_bar_title(APP_NAME, self.services.branding.logo_bytes()),
            bgcolor=Palette.PAPER, center_title=False, elevation=0, toolbar_height=64,
            actions=[
                ft.IconButton(icon=ft.Icons.STAR_ROUNDED, icon_color=Palette.INK, tooltip="Favorites",
                              on_click=lambda _e: self.navigate("favorites")),
                ft.IconButton(icon=ft.Icons.SETTINGS_ROUNDED, icon_color=Palette.INK, tooltip="Settings",
                              on_click=lambda _e: self.navigate("settings")),
            ])
        self.nav_bar = ft.NavigationBar(
            selected_index=0, bgcolor=Palette.SURFACE, indicator_color=Palette.GREEN_SOFT,
            on_change=lambda e: self.navigate(NAV_ORDER[int(e.control.selected_index)]),
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icon(ft.Icons.HOME_ROUNDED, color=Palette.MUTED), selected_icon=ft.Icon(ft.Icons.HOME_ROUNDED, color=Palette.GREEN_DARK), label="Home"),
                ft.NavigationBarDestination(icon=ft.Icon(ft.Icons.ADD_ROAD, color=Palette.MUTED), selected_icon=ft.Icon(ft.Icons.ADD_ROAD, color=Palette.GREEN_DARK), label="Log"),
                ft.NavigationBarDestination(icon=ft.Icon(ft.Icons.SAVINGS, color=Palette.MUTED), selected_icon=ft.Icon(ft.Icons.SAVINGS, color=Palette.GREEN_DARK), label="Savings"),
                ft.NavigationBarDestination(icon=ft.Icon(ft.Icons.INSIGHTS, color=Palette.MUTED), selected_icon=ft.Icon(ft.Icons.INSIGHTS, color=Palette.GREEN_DARK), label="Reports"),
            ])
        page.navigation_bar = self.nav_bar
        page.add(ft.SafeArea(expand=True, content=self.content))
        self.navigate("home")
        page.run_task(self._ticker)

    async def _ticker(self) -> None:
        last_day = date.today()
        while True:
            await asyncio.sleep(15)
            try:
                self.tick(datetime.now(), last_day)
                last_day = date.today()
            except Exception:
                self.log.exception("ticker failed")

    def tick(self, now: datetime, last_day: date) -> None:
        if self.live_header is not None:
            greeting, clock = self.live_header
            new_greeting, new_clock = greeting_for(now), clock_line(now)
            if greeting.value != new_greeting or clock.value != new_clock:
                greeting.value, clock.value = new_greeting, new_clock
                if ui.mounted(greeting):
                    greeting.update()
                    clock.update()
        stamp = self.services.branding.logo_stamp()
        if stamp != self._logo_stamp:
            self._logo_stamp = stamp
            self.refresh_brand()
        if now.date() != last_day and self.current and self.current[0] is DashboardView:
            self.show(*self.current[:1], **self.current[1])

    def refresh_brand(self) -> None:
        self.page.appbar.title = ui.brand_bar_title(APP_NAME, self.services.branding.logo_bytes())
        self.page.update()

    def navigate(self, name: str, **params) -> None:
        if name in NAV_ORDER:
            self.nav_bar.selected_index = NAV_ORDER.index(name)
        self.show(ROUTES[name], **params)

    def show(self, view_cls: type[BaseView], **params) -> None:
        self.current = (view_cls, params)
        try:
            view = view_cls(self, **params)
            self.content.content = view.build()
        except Exception:
            self.log.exception("Screen %s failed to build", view_cls.__name__)
            self.content.content = ui.empty_state(
                "Something went wrong on this screen. Please go back and try again.")
        self.page.update()

    def after_trip_logged(self, trip: Trip, saved: float = 0.0, reached=None) -> None:
        wallet = self.services.wallet.status()
        if reached:
            ui.notify(self.page, f"🎉 Trip saved and goal reached: {reached.label}!", Palette.SUCCESS)
        elif saved > 0:
            ui.notify(self.page, f"Trip saved. You saved {money(saved)} by choosing a cheaper route!",
                      Palette.SUCCESS)
        elif wallet.level == "over":
            ui.notify(self.page, f"Trip saved. Budget exceeded! Balance {money(wallet.remaining)}", Palette.DANGER)
        elif wallet.level == "low":
            ui.notify(self.page, f"Trip saved. Allowance running low: {money(wallet.remaining)} left", Palette.WARNING)
        else:
            ui.notify(self.page, f"Trip saved: {money(trip.total)}", Palette.SUCCESS)
        self.navigate("savings" if saved > 0 else "home")
