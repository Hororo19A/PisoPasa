from __future__ import annotations

import shutil
from pathlib import Path

from app.config import BRANDING_DIR

ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
MAX_BYTES = 2 * 1024 * 1024


class BrandingService:
    def __init__(self, folder: Path | None = None) -> None:
        self.folder = Path(folder) if folder else BRANDING_DIR

    def logo_path(self) -> Path | None:
        for ext in sorted(ALLOWED_EXTENSIONS):
            candidate = self.folder / f"logo{ext}"
            if candidate.is_file():
                return candidate
        return None

    def logo_bytes(self) -> bytes | None:
        path = self.logo_path()
        return path.read_bytes() if path else None

    def logo_stamp(self) -> float:
        path = self.logo_path()
        return path.stat().st_mtime if path else 0.0

    def set_logo(self, source: str | Path) -> Path:
        source = Path(source)
        if source.suffix.lower() not in ALLOWED_EXTENSIONS:
            raise ValueError("Use a PNG, JPG, WEBP or GIF image.")
        if not source.is_file():
            raise ValueError("The selected file could not be read.")
        if source.stat().st_size > MAX_BYTES:
            raise ValueError("Logo is too large. Please use an image under 2 MB.")
        self.folder.mkdir(parents=True, exist_ok=True)
        self.remove_logo()
        target = self.folder / f"logo{source.suffix.lower()}"
        shutil.copyfile(source, target)
        return target

    def remove_logo(self) -> None:
        for ext in ALLOWED_EXTENSIONS:
            (self.folder / f"logo{ext}").unlink(missing_ok=True)
