from __future__ import annotations

from app.config import BUS, JEEPNEY, MAX_ALTERNATIVES, MODERN_JEEP, TRICYCLE
from app.database.repositories import TripRepository
from app.models.entities import Leg, RouteOption, Trip
from app.services.fare_calculator import FareCalculator

STRATEGIES: list[tuple[str, set[str], str]] = [
    ("Cheapest mix", {JEEPNEY, MODERN_JEEP, BUS, TRICYCLE}, "Cheapest vehicle for each hop"),
    ("No tricycle", {JEEPNEY, MODERN_JEEP, BUS}, "Same hops without a tricycle"),
    ("Traditional jeep/bus", {JEEPNEY, BUS}, "Jeepney or bus only (no modern jeep)"),
    ("Jeepney only", {JEEPNEY}, "Jeepney for every hop"),
]


class RouteFinderService:
    def __init__(self, calculator: FareCalculator, trips: TripRepository | None = None) -> None:
        self.calc = calculator
        self.trips = trips

    def find_alternatives(self, trip: Trip) -> list[RouteOption]:
        rules = self.calc.rules()
        actual_vehicles = tuple(l.vehicle for l in trip.legs)
        seen: set[tuple[str, ...]] = {actual_vehicles}
        options: list[RouteOption] = []

        for name, allowed, why in STRATEGIES:
            legs: list[Leg] = []
            for leg in trip.legs:
                priced = [(self.calc.compute(rules[v], leg.distance_km), v)
                          for v in allowed if v in rules]
                if not priced:
                    break
                fare, vehicle = min(priced)
                legs.append(Leg(vehicle, leg.distance_km, fare))
            else:
                key = tuple(l.vehicle for l in legs)
                if key in seen:
                    continue
                seen.add(key)
                total = round(sum(l.fare for l in legs), 2)
                options.append(RouteOption(
                    label=" → ".join(key), note=why,
                    legs=legs, total=total, savings=round(trip.total - total, 2)))

        options.sort(key=lambda o: o.total)
        return options[:MAX_ALTERNATIVES]

    def suggest(self, origin: str, destination: str, legs: list[Leg]) -> list[RouteOption]:
        current = round(sum(l.fare for l in legs), 2)
        if current <= 0:
            return []
        options: list[RouteOption] = []

        if self.trips and origin.strip() and destination.strip():
            for past in self.trips.same_route_cheaper(origin, destination, current):
                vehicles = " → ".join(l.vehicle for l in past.legs)
                options.append(RouteOption(
                    label=vehicles, note=f"You paid this for the same trip on {past.logged_at[:10]}",
                    legs=[Leg(l.vehicle, l.distance_km, l.fare) for l in past.legs],
                    total=past.total, savings=round(current - past.total, 2), source="history"))

        if legs and all(l.distance_km > 0 and l.fare > 0 for l in legs):
            for opt in self.find_alternatives(Trip(origin, destination, legs)):
                if opt.savings > 0:
                    options.append(opt)

        unique: dict[tuple, RouteOption] = {}
        for opt in sorted(options, key=lambda o: (o.total, o.source != "history")):
            unique.setdefault((tuple(l.vehicle for l in opt.legs), opt.total), opt)
        return list(unique.values())[:MAX_ALTERNATIVES]
