from __future__ import annotations

from datetime import date, datetime, timedelta

from app.database.repositories import SavingsRepository, TripRepository


def _since(days: int) -> str:
    return (datetime.combine(date.today(), datetime.min.time()) - timedelta(days=days - 1)).isoformat(timespec="seconds")


class ReportService:
    def __init__(self, trips: TripRepository, savings: SavingsRepository) -> None:
        self.trips = trips
        self.savings = savings

    def report(self, days: int) -> dict:
        since = _since(days)
        return {
            "days": days,
            "total_fare": self.trips.total_since(since),
            "total_savings": self.savings.total_since(since),
            "by_vehicle": self.trips.by_vehicle_since(since),
            "by_route": self.trips.by_route_since(since),
            "daily": self.trips.daily_totals_since(since),
        }

    def weekly(self) -> dict:
        return self.report(7)

    def monthly(self) -> dict:
        return self.report(30)
