from __future__ import annotations

from app.database.repositories import FavoriteRepository
from app.models.entities import FavoriteRoute, Leg, Trip
from app.services.trip_service import TripService


class FavoriteService:
    def __init__(self, favorites: FavoriteRepository, trip_service: TripService) -> None:
        self.favorites = favorites
        self.trip_service = trip_service

    def save(self, name: str, origin: str, destination: str, legs: list[Leg]) -> None:
        TripService.validate(origin, destination, legs)
        self.favorites.add(FavoriteRoute(name.strip() or f"{origin} → {destination}",
                                         origin.strip(), destination.strip(), legs))

    def all(self) -> list[FavoriteRoute]:
        return self.favorites.all()

    def delete(self, fav_id: int) -> None:
        self.favorites.delete(fav_id)

    def log_one_tap(self, fav: FavoriteRoute) -> Trip:
        legs = [Leg(l.vehicle, l.distance_km, l.fare) for l in fav.legs]
        return self.trip_service.log_trip(fav.origin, fav.destination, legs)
