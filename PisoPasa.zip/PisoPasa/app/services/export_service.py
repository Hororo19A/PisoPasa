from __future__ import annotations

import csv
import platform
from datetime import datetime
from pathlib import Path

from app.config import APP_NAME, APP_VERSION, export_dir, log_path
from app.database.repositories import SavingsRepository, TripRepository


class ExportService:
    def __init__(self, trips: TripRepository, savings: SavingsRepository,
                 folder: Path | None = None) -> None:
        self.trips = trips
        self.savings = savings
        self.folder = folder

    def export_all(self) -> list[Path]:
        folder = self.folder or export_dir()
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        trips_file = folder / f"pisopasa_trips_{stamp}.csv"
        savings_file = folder / f"pisopasa_savings_{stamp}.csv"
        self._write(trips_file,
                    ["trip_id", "logged_at", "origin", "destination", "leg_no",
                     "vehicle", "distance_km", "leg_fare", "trip_total"],
                    self.trips.export_rows())
        self._write(savings_file,
                    ["id", "created_at", "trip_id", "route", "before", "after", "before_total",
                     "after_total", "amount_saved", "source", "label"],
                    self.savings.export_rows())
        return [trips_file, savings_file]

    def report_text(self, max_log_lines: int = 40) -> str:
        source = log_path()
        lines = source.read_text(encoding="utf-8", errors="replace").splitlines()[-max_log_lines:] \
            if source.is_file() else []
        header = (f"{APP_NAME} v{APP_VERSION}\nPython {platform.python_version()} on {platform.platform()}\n"
                  f"Time: {datetime.now():%Y-%m-%d %H:%M}\n--- recent errors ---\n")
        return header + ("\n".join(lines) if lines else "(no errors recorded)")

    def export_log(self) -> Path:
        folder = self.folder or export_dir()
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / f"pisopasa_report_{datetime.now():%Y%m%d_%H%M%S}.txt"
        target.write_text(self.report_text(200), encoding="utf-8")
        return target

    @staticmethod
    def _write(path: Path, header: list[str], rows: list[list]) -> None:
        with path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(header)
            writer.writerows(rows)
