from __future__ import annotations

import math

from app.database.repositories import FareRepository
from app.models.entities import FareRule


class FareCalculator:
    def __init__(self, fares: FareRepository) -> None:
        self.fares = fares

    def rules(self) -> dict[str, FareRule]:
        return self.fares.all_rules()

    @staticmethod
    def compute(rule: FareRule, distance_km: float) -> float:
        if distance_km <= rule.base_km:
            return round(rule.base_fare, 2)
        extra_km = math.ceil(distance_km - rule.base_km)
        return round(rule.base_fare + extra_km * rule.per_km, 2)

    def estimate(self, vehicle: str, distance_km: float) -> float:
        rule = self.rules().get(vehicle)
        if rule is None or distance_km <= 0:
            return 0.0
        return self.compute(rule, distance_km)
