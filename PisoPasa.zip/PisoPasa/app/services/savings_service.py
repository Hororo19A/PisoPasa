from __future__ import annotations

from app.database.repositories import SavingsRepository, TripRepository
from app.models.entities import Leg, SavingsGoal, Trip, legs_text


class SavingsService:
    def __init__(self, savings: SavingsRepository, trips: TripRepository) -> None:
        self.savings = savings
        self.trips = trips

    def total(self) -> float:
        return self.savings.total()

    def history(self):
        return self.savings.history()

    def active_goal(self) -> SavingsGoal | None:
        return self.savings.active_goal()

    def achieved_goals(self) -> list[SavingsGoal]:
        return self.savings.achieved_goals()

    def set_goal(self, label: str, target: float) -> None:
        if target <= 0:
            raise ValueError("Target must be greater than 0.")
        self.savings.add_goal(label.strip() or "My savings goal", target)

    def record_switch(self, trip: Trip, baseline_total: float, label: str = "",
                      before_legs: list[Leg] | None = None,
                      source: str = "") -> tuple[float, SavingsGoal | None]:
        amount = round(baseline_total - trip.total, 2)
        if amount <= 0:
            raise ValueError("The chosen route is not cheaper than the original entry.")
        if trip.saved:
            raise ValueError("Savings for this trip were already recorded.")
        before = legs_text(before_legs) if before_legs else f"₱{baseline_total:,.2f}"
        self.savings.add_saving(
            trip.id, amount, label or "Cheaper route", route_text=trip.route_text,
            before_desc=before, after_desc=legs_text(trip.legs), before_total=round(baseline_total, 2),
            after_total=trip.total, source=source)
        self.trips.mark_saved(trip.id)

        goal = self.savings.active_goal()
        reached = None
        if goal:
            goal.saved = round(goal.saved + amount, 2)
            if goal.saved >= goal.target:
                goal.achieved = True
                reached = goal
            self.savings.update_goal(goal)
        return amount, reached
