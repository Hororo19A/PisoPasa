from __future__ import annotations

from app.database.repositories import TripRepository
from app.models.entities import Leg, Trip


class ValidationError(ValueError):
    pass


class TripService:
    def __init__(self, trips: TripRepository) -> None:
        self.trips = trips

    @staticmethod
    def validate(origin: str, destination: str, legs: list[Leg]) -> None:
        if not origin.strip() or not destination.strip():
            raise ValidationError("Enter both origin and destination.")
        if not legs:
            raise ValidationError("Add at least one leg.")
        for i, leg in enumerate(legs, start=1):
            if leg.distance_km <= 0:
                raise ValidationError(f"Leg {i}: distance must be greater than 0.")
            if leg.fare <= 0:
                raise ValidationError(f"Leg {i}: fare must be greater than 0.")

    def log_trip(self, origin: str, destination: str, legs: list[Leg]) -> Trip:
        self.validate(origin, destination, legs)
        trip = Trip(origin.strip(), destination.strip(), legs)
        trip.id = self.trips.add(trip)
        return self.trips.get(trip.id)

    def recent(self, limit: int = 20) -> list[Trip]:
        return self.trips.recent(limit)

    def get(self, trip_id: int) -> Trip | None:
        return self.trips.get(trip_id)
