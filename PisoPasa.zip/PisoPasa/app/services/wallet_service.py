from __future__ import annotations

from app.config import LOW_BALANCE_RATIO
from app.database.repositories import SettingsRepository, TripRepository, now_iso
from app.models.entities import WalletStatus


class WalletService:
    def __init__(self, settings: SettingsRepository, trips: TripRepository) -> None:
        self.settings = settings
        self.trips = trips

    def set_starting_balance(self, amount: float) -> None:
        self.settings.set("wallet_start", f"{amount:.2f}")
        self.settings.set("wallet_since", now_iso())

    def status(self) -> WalletStatus:
        start_raw = self.settings.get("wallet_start")
        if start_raw is None:
            return WalletStatus(0.0, 0.0, 0.0, "unset")
        starting = float(start_raw)
        spent = self.trips.total_since(self.settings.get("wallet_since", "1970-01-01"))
        remaining = round(starting - spent, 2)
        if remaining < 0:
            level = "over"
        elif starting > 0 and remaining <= starting * LOW_BALANCE_RATIO:
            level = "low"
        else:
            level = "ok"
        return WalletStatus(starting, spent, remaining, level)
