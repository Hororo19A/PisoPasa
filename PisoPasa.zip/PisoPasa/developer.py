import flet as ft

from app.developer.dev_app import DeveloperApp


def main(page: ft.Page) -> None:
    DeveloperApp(page).start()


if __name__ == "__main__":
    ft.run(main)
