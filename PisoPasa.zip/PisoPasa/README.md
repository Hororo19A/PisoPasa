# PisoPasa

A Mobile-Based Multi-Hop Fare Tracking, Route Optimization, and Savings Management System for Tacloban City
Public Transit Commuters (IT 122/122L System Analysis and Design, Leyte Normal University).

PisoPasa is a stand-alone, **offline** Android app written in **Python** with **Flet** (screens) and **SQLite**
(database). There is no login, no server and no GPS: everything is saved on the commuter's own device.

## 1. What the app does

| Screen | What the commuter can do |
|---|---|
| **Home** | See today's, this week's, this month's and this year's fare spending (donut chart by vehicle), the Fare Allowance Wallet with low / over-budget warnings, the savings goal, quick actions and recent trips. The greeting (umaga / tanghali / hapon / gabi) and the date/time line update by themselves. |
| **Log** | Enter an origin and destination, then each hop (vehicle, distance, fare paid). The fare is suggested from the fare matrix and the trip total is added up automatically. A **Cheaper routes** list appears under the hops (see section 8). Trips can be saved as favorites. |
| **Savings** | Total saved, an optional savings goal (target amount and name) that fills automatically with a milestone message, and a readable history of every saving. |
| **Reports** | Weekly or monthly spending per day, per vehicle type (donut) and top routes, plus the amount saved. |
| **Favorites** (star in the top bar) | Saved routes that can be logged again with one tap. |
| **Settings** (gear in the top bar) | Set or reset the wallet balance, edit the fare matrix, export trips and savings to CSV, and **Report a problem** (see section 9). |

Vehicles in the fare matrix: Jeepney, Modern Jeep, Bus, Tricycle.

## 2. Folder layout

```
main.py                     user app entry point (no logic here)
developer.py                Developer Console entry point (never shipped as the app's screen)
README.md                   this file
DEVELOPER_GUIDE.md          for a developer who takes over the project
CHANGELOG.md                version history
requirements.txt            flet, flet-charts
pyproject.toml              project name, version, build settings
tests/                      automatic tests
app/
  config.py                 constants: vehicles, app version, support email, data folders
  container.py              creates the database and every service once
  pisopasa_app.py           app shell: window, top bar, bottom navigation, live clock, error catching
  logging_setup.py          writes errors to data/pisopasa.log
  models/entities.py        data classes: Trip, Leg, FavoriteRoute, RouteOption, SavingsEntry ...
  database/
    schema.py               table definitions and the sample fare matrix
    migrations.py           numbered database upgrades (keeps users' data on updates)
    connection.py           SQLite wrapper
    repositories.py         all SQL, one class per table group
  services/                 the rules and calculations (no screen code)
    fare_calculator.py      fare from the matrix (base fare + each extra km)
    wallet_service.py       Fare Allowance Wallet and its warnings
    trip_service.py         trip logging and validation
    favorite_service.py     favorite routes and one-tap logging
    route_finder_service.py cheaper route suggestions (history + fare matrix)
    savings_service.py      savings, goals and milestones
    report_service.py       dashboard totals and weekly/monthly reports
    export_service.py       CSV export and the problem report
    branding_service.py     reads the logo (only the Developer Console changes it)
  branding/                 the logo file (logo.png / .jpg / .webp / .gif) lives here
  ui/
    theme.py                DESIGN: colours, corner radius, spacing, fonts, vehicle colours
    components.py           reusable pieces: cards, tabs, buttons, charts, fields, dialogs
    formatters.py           money / date / number helpers
    greeting.py             time-based greeting
    views/                  one file per screen (dashboard, trip_log, favorites, savings, reports, settings)
  developer/                Developer Console (separate app, see section 7)
```

Where to change what: **looks** in `ui/theme.py`, **screens** in `ui/views/`, **rules** in `services/`,
**SQL** in `database/`.

## 3. Run it in VS Code

1. Install Python and open this folder in VS Code (File > Open Folder).
2. In the VS Code terminal:
   ```
   python -m venv .venv
   .venv\Scripts\activate            (macOS/Linux: source .venv/bin/activate)
   pip install -r requirements.txt
   ```
3. Choose the interpreter: `Ctrl+Shift+P` > **Python: Select Interpreter** > the `.venv` one.
4. **Live preview** (the window refreshes every time you save a file):
   ```
   flet run -d -r main.py
   ```
   Add `--web` to preview in the browser instead of a window.
5. **Tests:** `python -m unittest discover -s tests -v`
6. **Developer Console:** `flet run -d -r developer.py`.

To try the app on a real phone, install the **Flet** app from the Play Store and run
`flet run --android main.py`.

Where data is saved while developing: the `data/` folder next to `main.py` (`pisopasa.db`, `pisopasa.log`,
`exports/`, `backups/`, `code_backups/`). On an Android phone it is the app's private storage.

## 4. Python version

The code needs Python 3.10 or newer and uses only the standard library plus Flet. It has been run on
Python 3.15 on Windows. If `pip install` fails on a very new Python because a package has no build for it yet,
use Python 3.13 or 3.14. The Android APK bundles its own Python (Flet supports 3.12 to 3.14), so build it with
`--python-version 3.13`.

## 5. Build the Android app

```
pip install -r requirements.txt
flet build apk --python-version 3.13 --build-number 1 --build-version 1.0.0
```
The first build downloads Flutter and may ask for a JDK and the Android SDK (the output lists what is missing).
The installable file appears in `build/`. Copy the `.apk` to the phone and install it (allow "install unknown
apps"). The app needs Android 8.0 or newer, no internet and no GPS.

For a release to other people, sign the app with your own key (Flet docs: *Publish > Android*) and use the same
key for every update. See `DEVELOPER_GUIDE.md` for the full release routine.

## 6. Before real use

* The fare matrix holds **sample** numbers. Check the current LTFRB and Tacloban City rates and enter them in
  **Settings > Fare matrix**. For new installs, change `DEFAULT_FARES` in `app/database/schema.py`.
* Optional: put your email in `SUPPORT_EMAIL` in `app/config.py` to turn on **Email developer** in Settings.

## 7. Developer Console

A separate app for the person who looks after PisoPasa. Users never see it: the user app has no button or link
that opens it. Both apps use the same `data/` folder on your PC.

| Tab | Use |
|---|---|
| **Brand** | Upload or remove the app logo (PNG, JPG, WEBP or GIF, up to 2 MB). It is saved in `app/branding/` and goes into the next build. A running copy of the user app redraws its top bar within about 15 seconds. |
| **Health** | Database check, rows per table, app / Python / Flet / database versions, and the latest error log. |
| **Code** | Browse and edit project files, upload a file or a `.zip` update package, automatic backups and **Restore**. Python files are syntax-checked before they are saved. |
| **Tools** | Run the tests, back up the database, repair / optimize it, or reset user data. |

## 8. Cheaper routes while logging

There is no separate cheaper-route screen. On **Log**, once the origin, destination and fares are filled in, the
**Cheaper routes** list appears. Each card says why it is suggested and what changes:

* **From your trip history:** the same origin and destination was logged before for less.
* **From your fare matrix:** the same hops priced with other vehicles (cheapest vehicle for each hop, no tricycle,
  jeepney or bus only, jeepney only).
* One line per hop, for example `Hop 1: Tricycle ₱60.00 → Jeepney ₱14.80`, the new total and the amount saved.

Tap **Choose this route** to replace the hops (**Undo** brings the first entry back). When the trip is saved, the
difference from the first entry is added to **Savings** and to the savings goal. On Home, **Repeat trip** reopens a
past trip on the Log screen to look for cheaper routes.

## 9. Errors and problem reports

* If a screen fails, the user sees a short friendly message instead of a crash, and the full error is written to
  `data/pisopasa.log`.
* **Settings > Report a problem** saves a small text report (app version, device info, recent error messages; never
  trips or money) that the user can send to the developer. If `SUPPORT_EMAIL` is set, **Email developer** opens the
  email app with the report filled in. The app is offline, so it never sends anything by itself.

## 10. Updates and handing the project over

Updates are delivered as a new APK. The database upgrades itself on first start (`app/database/migrations.py`), so
users keep their trips and savings. See `DEVELOPER_GUIDE.md` for access to the code, the release steps and the
handover checklist.
