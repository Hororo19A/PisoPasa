# Changelog

## 1.0.0 (2026-10-17)
- First release of PisoPasa.
- Fare Allowance Wallet with low-budget and over-budget warnings.
- Multi-hop trip logging with automatic fare suggestions from the fare matrix.
- Favorite routes with one-tap logging.
- Cheaper route suggestions on the Log screen ("Choose this route"), from trip history and the fare matrix.
- Savings tracker with goals and a readable savings history.
- Weekly and monthly reports with charts.
- CSV export, error report for bug fixing, and a live greeting.
- Developer Console: logo, health, code editor/upload with backups, and tools.
