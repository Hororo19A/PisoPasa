# PisoPasa Developer Guide

For anyone who takes over the app: a teammate, a classmate, or yourself later. Users never see any of this; they
only install the APK. Read `README.md` first for what the app does and how the folders are organised.

## 1. Getting access to the code

The project lives in one Git repository on GitHub. A new developer needs three things from the current owner:

| What | How it is handed over | Rule |
|---|---|---|
| The repository | GitHub > repository > Settings > Collaborators > Add people (or transfer the repository) | |
| The Android signing key (`.jks` file and its passwords) | A private channel such as a password manager or private drive | Never put it in Git (`.gitignore` blocks `*.jks`, `*.keystore`, `*.pem`, `.env`) |
| This guide and `README.md` | They are inside the repository | |

Without the signing key, a new build cannot update phones that already have the app (Android refuses a different
key). Keep the key in two safe places.

No Git? Share the project folder as a `.zip` and leave out `data`, `build` and `.venv`. Another developer can load
changed files through the Developer Console (section 4).

## 2. First-time setup (about 10 minutes)

```
git clone <repo-url>
cd PisoPasa
python -m venv .venv
.venv\Scripts\activate            (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python -m unittest discover -s tests     (must say OK)
flet run -d -r main.py                   (user app with live reload)
flet run -d -r developer.py              (Developer Console)
```
Any Python from 3.10 up works.

## 3. How the code is organised

The code has no comments on purpose; the structure and this guide explain it.

| Layer | Folder | Rule |
|---|---|---|
| Data classes | `app/models/` | Plain data only, no screens and no SQL |
| Database | `app/database/` | All SQL is in `repositories.py`; only `connection.py` opens SQLite |
| Logic | `app/services/` | Rules and calculations; no screen code |
| Design | `app/ui/theme.py` | Colours, corners, spacing, fonts, vehicle colours |
| Widgets | `app/ui/components.py` | Reusable pieces used by the screens |
| Screens | `app/ui/views/` | One class per screen, each has `build()` and returns the layout |
| Shell | `app/pisopasa_app.py` | Window, top bar, bottom tabs, live clock, error catching |
| Wiring | `app/container.py` | Builds the database and all services once |
| Developer tools | `app/developer/` | The Developer Console (not part of the user screens) |

| I want to change... | Edit |
|---|---|
| Colours, corners, fonts | `app/ui/theme.py` |
| How a screen looks | `app/ui/views/<name>_view.py` |
| A widget used on several screens | `app/ui/components.py` |
| A rule or calculation | the matching file in `app/services/` |
| An SQL query | `app/database/repositories.py` |
| A database table or column | add a migration (section 6) |
| Default fare values for new installs | `DEFAULT_FARES` in `app/database/schema.py` |
| The wallet warning level | `LOW_BALANCE_RATIO` in `app/config.py` |
| How many suggestions are shown | `MAX_ALTERNATIVES` in `app/config.py` |
| The logo | Developer Console > Brand |
| The support email | `SUPPORT_EMAIL` in `app/config.py` |

### Adding a screen
1. Create `app/ui/views/<name>_view.py` with a class that extends `BaseView` and implements `build()`.
2. Register it in `ROUTES` in `app/pisopasa_app.py`.
3. For a bottom tab, also add it to `NAV_ORDER` and add a matching `NavigationBarDestination` in `start()`.
4. Open it from anywhere with `self.app.navigate("<key>")`.

### Adding a vehicle type
Add its name to `VEHICLES` in `app/config.py` and its colour and icon to `VEHICLE_STYLE` in `app/ui/theme.py`. Existing
installs only seed the fare matrix when it is empty, so add a migration that inserts the new row into `fare_matrix`.
Check `STRATEGIES` in `route_finder_service.py` too.

## 4. The Developer Console

Run it with `flet run -d -r developer.py`. It uses the same `data/` folder as the user app.

| Tab | What it does |
|---|---|
| **Brand** | Upload or remove the logo. Saved in `app/branding/`; a running user app picks it up within about 15 seconds, and new APK builds include it. |
| **Health** | Database integrity, rows per table, versions (app, schema, Python, Flet) and the latest error log. |
| **Code** | Browse, edit and upload code (below). |
| **Tools** | Run the tests, back up the database, repair / optimize it, reset user data (asks first). |

### Code tab (changing code without VS Code or Git)
* **Browse and edit:** open a file, change it, press **Save**. Python files are syntax-checked first, so a typo
  cannot be saved.
* **Upload a file** into the folder you are browsing, or an **update package**: a `.zip` of changed project files.
  The paths inside the zip decide where each file goes. A wrapper folder such as `PisoPasa/` is removed
  automatically. If one file in the zip has a syntax error, nothing is written.
* **Ignored on purpose:** `data/`, `.git`, `.venv`, `build`, `dist` and any file that is not code or text.
* **Backups:** every file that is overwritten is first copied to `data/code_backups/<time>/`. **Restore** puts a
  backup back (and keeps a copy of what it replaced).
* With `flet run -d -r main.py` running, the app reloads by itself after a save.
* **Open in VS Code** (needs the `code` command on PATH) is there for bigger edits.

## 5. Handling a bug report

1. The user opens **Settings > Report a problem** and sends you the report (file, or email if `SUPPORT_EMAIL` is
   set). It holds the app version, device info and recent error messages, never trips or money. You can also read
   `data/pisopasa.log` on your own PC.
2. Run the app with live reload and open Developer Console > **Health** to see the latest errors.
3. Reproduce it. Write a test for it in `tests/` first when you can.
4. Fix the code until `python -m unittest discover -s tests` says OK.
5. Release the fix (section 7).

## 6. Changing the database safely

Users have real data on their phones, so the database is versioned. `app/database/migrations.py` holds a numbered
list `MIGRATIONS`. On start, every migration newer than the database's version runs once, in order.

To add a column or table:
1. Add a new tuple at the **end** of `MIGRATIONS`, for example
   `(3, "ALTER TABLE trips ADD COLUMN note TEXT NOT NULL DEFAULT '';")`.
2. Update the repository code that reads and writes it.
3. Add a test (see `tests/test_suggestions_and_release.py`, which checks that an old database is upgraded without
   losing data).
4. Release.

Never edit an old migration; users have already run it. Health > Versions shows the database version
(`Schema vN (latest vM)`).

## 7. Releasing an update

Updates are a new APK (the app is offline, so code cannot be pushed to phones).

1. **Test:** `python -m unittest discover -s tests` must say OK.
2. **Raise the version** in both `app/config.py` (`APP_VERSION`) and `pyproject.toml` (`version`). A test fails if
   they differ. Add a short entry to `CHANGELOG.md`.
3. **Save to GitHub** (if Git is set up):
   `git add -A`, `git commit -m "Fix: ..."`, `git tag -a v1.0.1 -m "v1.0.1"`, `git push --follow-tags`.
4. **Build:** `flet build apk --python-version 3.13 --build-number 2 --build-version 1.0.1`.
   The build number must be higher than the one on users' phones, so raise it on every release.
5. **Sign with the same key every time** (section 1).
6. **Share the APK:** a GitHub Release, Google Drive, or the Play Store.

Users install the new APK over the old one. Their trips and savings stay because the database upgrades itself.

## 8. The tests

`python -m unittest discover -s tests -v` runs everything in about a second.

| File | Covers |
|---|---|
| `test_services.py` | Fare maths, trips, wallet levels, route finder, savings and goals, favorites, reports, CSV export, logo |
| `test_suggestions_and_release.py` | Cheaper-route suggestions, the Log screen flow, migrations, version numbers matching |
| `test_ui_smoke.py` | Every screen builds without errors |
| `test_developer_and_live.py` | Greeting times, live ticker, error catching, developer diagnostics and panels |
| `test_code_service.py` | The Code tab's safety rules (paths, syntax checks, backups, zip updates) and the problem report |

The tests prove that the code runs and the screens build. They cannot show how a screen looks, so click through the
app after UI changes.

## 9. Working as a team

* Do not edit `main` directly: make a branch (`fix/short-name`), open a Pull Request, let someone review it, merge.
* One person builds and publishes releases (the one who holds the signing key).
* Keep `CHANGELOG.md` up to date; it is the first thing the next developer reads.

## 10. Troubleshooting

| Problem | What to do |
|---|---|
| `flet` is not recognised | Activate the virtual environment, or use `python -m flet run -d -r main.py` |
| `pip install` fails on a very new Python | Use Python 3.13 or 3.14 for development |
| A screen shows "Something went wrong" | Read Developer Console > Health > Error log |
| The window shows an old design | Stop and restart `flet run`; make sure `-d -r` are included |
| Logo upload does nothing | Use the desktop Developer Console, not `--web`; the file must be an image under 2 MB |
| APK build asks for Java or the Android SDK | Install what the build output names, then run the build again |
| A new APK will not install over the old one | The signing key or the build number is different from the installed app |
| You need to start fresh while testing | Developer Console > Tools > Reset user data (back up first) |

## 11. Handover checklist (for the person leaving)

- [ ] New developer added to the GitHub repository (or the repository transferred)
- [ ] Signing key and passwords handed over privately, with a backup copy
- [ ] New developer ran the tests successfully
- [ ] New developer built an APK on their own PC
- [ ] Access shared to the place where APKs are published
- [ ] Known bugs written down as GitHub Issues
