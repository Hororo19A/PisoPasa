import tempfile
import unittest
from pathlib import Path

from app.container import ServiceContainer
from app.models.entities import Leg
from app.services.trip_service import ValidationError


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.c = ServiceContainer(":memory:", Path(self.tmp.name))

    def tearDown(self):
        self.tmp.cleanup()

    def _trip(self):
        return self.c.trips.log_trip("Home", "School", [
            Leg("Tricycle", 2.0, 30.0), Leg("Modern Jeep", 6.0, 25.0)])

    def test_fare_calculation(self):
        self.assertEqual(self.c.calculator.estimate("Jeepney", 3), 13.0)
        self.assertEqual(self.c.calculator.estimate("Jeepney", 7.2), 20.2)

    def test_trip_total_and_validation(self):
        self.assertEqual(self._trip().total, 55.0)
        with self.assertRaises(ValidationError):
            self.c.trips.log_trip("", "X", [Leg("Bus", 1, 10)])

    def test_wallet_levels(self):
        self.assertEqual(self.c.wallet.status().level, "unset")
        self.c.wallet.set_starting_balance(100)
        self._trip()
        w = self.c.wallet.status()
        self.assertEqual((w.spent, w.remaining, w.level), (55.0, 45.0, "ok"))
        self._trip()
        self.assertEqual(self.c.wallet.status().level, "over")

    def test_route_finder_and_savings_goal(self):
        trip = self._trip()
        options = self.c.finder.find_alternatives(trip)
        self.assertTrue(1 <= len(options) <= 3)
        self.assertTrue(all(o.total <= options[-1].total for o in options))
        best = options[0]
        self.assertGreater(best.savings, 0)
        self.assertTrue(best.note)
        self.c.savings.set_goal("Shoes", best.savings)
        new_trip = self.c.trips.log_trip("Home", "School", best.legs)
        amount, reached = self.c.savings.record_switch(new_trip, trip.total, best.label, trip.legs, "matrix")
        self.assertEqual(amount, best.savings)
        self.assertIsNotNone(reached)
        entry = self.c.savings.history()[0]
        self.assertEqual(entry.route_text, "Home → School")
        self.assertIn("Tricycle", entry.before_desc)
        self.assertEqual(entry.after_total, new_trip.total)
        with self.assertRaises(ValueError):
            self.c.savings.record_switch(self.c.trips.get(new_trip.id), trip.total)

    def test_favorites_one_tap(self):
        legs = [Leg("Jeepney", 5, 15.8)]
        self.c.favorites.save("Home to School", "Home", "School", legs)
        fav = self.c.favorites.all()[0]
        trip = self.c.favorites.log_one_tap(fav)
        self.assertEqual(trip.total, 15.8)

    def test_reports_and_export(self):
        self._trip()
        weekly = self.c.reports.weekly()
        self.assertEqual(weekly["total_fare"], 55.0)
        self.assertEqual(dict(weekly["by_vehicle"])["Tricycle"], 30.0)
        files = self.c.export.export_all()
        self.assertTrue(all(f.exists() for f in files))


if __name__ == "__main__":
    unittest.main()


class BrandingTests(unittest.TestCase):
    def test_logo_upload_and_remove(self):
        with tempfile.TemporaryDirectory() as tmp:
            c = ServiceContainer(":memory:", None, Path(tmp) / "brand")
            self.assertIsNone(c.branding.logo_bytes())
            src = Path(tmp) / "mylogo.png"
            src.write_bytes(b"\x89PNG fake")
            c.branding.set_logo(src)
            self.assertEqual(c.branding.logo_bytes(), b"\x89PNG fake")
            with self.assertRaises(ValueError):
                c.branding.set_logo(Path(tmp) / "x.exe")
            c.branding.remove_logo()
            self.assertIsNone(c.branding.logo_bytes())
