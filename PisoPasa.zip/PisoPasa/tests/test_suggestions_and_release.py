import re
import sqlite3
import unittest
from unittest.mock import MagicMock

from app.config import APP_VERSION, PROJECT_ROOT
from app.container import ServiceContainer
from app.database.migrations import LATEST_VERSION, current_version, migrate
from app.models.entities import Leg
from app.pisopasa_app import PisoPasaApp
from app.ui.views.trip_log_view import TripLogView


class SuggestionTests(unittest.TestCase):
    def setUp(self):
        self.c = ServiceContainer(":memory:")

    def test_history_suggestion_same_route_cheaper(self):
        self.c.trips.log_trip("Palo", "Tacloban", [Leg("Jeepney", 5, 20.0)])
        entered = [Leg("Tricycle", 5, 60.0)]
        options = self.c.finder.suggest(" palo ", "TACLOBAN", entered)
        history = [o for o in options if o.source == "history"]
        self.assertEqual(len(history), 1)
        self.assertEqual((history[0].total, history[0].savings), (20.0, 40.0))

    def test_other_route_is_not_suggested_from_history(self):
        self.c.trips.log_trip("Palo", "Dulag", [Leg("Jeepney", 5, 5.0)])
        options = self.c.finder.suggest("Palo", "Tacloban", [Leg("Jeepney", 5, 20.0)])
        self.assertTrue(all(o.source != "history" for o in options))

    def test_matrix_suggestion_and_cap(self):
        options = self.c.finder.suggest("A", "B", [Leg("Tricycle", 6, 80.0), Leg("Tricycle", 3, 30.0)])
        self.assertTrue(1 <= len(options) <= 3)
        self.assertTrue(all(o.savings > 0 for o in options))
        self.assertEqual(self.c.finder.suggest("A", "B", [Leg("Jeepney", 0, 0)]), [])

    def test_record_switch_fills_goal_once(self):
        self.c.savings.set_goal("Shoes", 25)
        trip = self.c.trips.log_trip("A", "B", [Leg("Jeepney", 5, 20.0)])
        amount, reached = self.c.savings.record_switch(trip, 60.0, "From your history")
        self.assertEqual(amount, 40.0)
        self.assertIsNotNone(reached)
        with self.assertRaises(ValueError):
            self.c.savings.record_switch(self.c.trips.get(trip.id), 60.0, "x")
        with self.assertRaises(ValueError):
            self.c.savings.record_switch(self.c.trips.log_trip("A", "B", [Leg("Jeepney", 5, 20)]), 20.0, "x")

    def test_log_screen_choose_route_then_save_records_savings(self):
        self.c.trips.log_trip("Palo", "Tacloban", [Leg("Jeepney", 5, 20.0)])
        app = PisoPasaApp(MagicMock(), self.c)
        app.start()
        view = TripLogView(app)
        view.build()
        view.origin.value, view.destination.value = "Palo", "Tacloban"
        view.editors[0].vehicle.value = "Tricycle"
        view.editors[0].distance.value = "5"
        view.editors[0].fare.value = "60"
        view._recalc()
        cards = view.suggest_column.controls
        self.assertTrue(cards and not isinstance(cards[0], type(None)))
        option = next(o for o in self.c.finder.suggest("Palo", "Tacloban", view._current_legs())
                      if o.source == "history")
        view._choose(option)
        self.assertEqual(view.baseline, 60.0)
        self.assertEqual(view.total_text.value, "₱20.00")
        view._save(None)
        self.assertEqual(self.c.savings.total(), 40.0)
        view2 = TripLogView(app); view2.build()
        view2._undo(None)


class ReleaseTests(unittest.TestCase):
    def test_migrations_fresh_and_idempotent(self):
        db = ServiceContainer(":memory:").db
        self.assertEqual(current_version(db.conn), LATEST_VERSION)
        self.assertEqual(migrate(db.conn), LATEST_VERSION)

    def test_old_install_is_upgraded_without_losing_data(self):
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        conn.execute("INSERT INTO settings VALUES ('wallet_start','150')")
        conn.commit()
        self.assertEqual(migrate(conn), LATEST_VERSION)
        self.assertEqual(conn.execute("SELECT value FROM settings").fetchone()[0], "150")

    def test_version_numbers_match(self):
        text = (PROJECT_ROOT / "pyproject.toml").read_text(encoding="utf-8")
        version = re.search(r'^version\s*=\s*"([^"]+)"', text, re.M).group(1)
        self.assertEqual(version, APP_VERSION, "Bump APP_VERSION (config.py) and pyproject.toml together")


if __name__ == "__main__":
    unittest.main()
