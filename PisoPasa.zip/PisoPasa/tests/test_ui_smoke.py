import unittest
from unittest.mock import MagicMock

from app.container import ServiceContainer
from app.models.entities import Leg
from app.pisopasa_app import ROUTES, PisoPasaApp


class UiSmokeTests(unittest.TestCase):
    def test_every_view_builds(self):
        services = ServiceContainer(":memory:")
        services.wallet.set_starting_balance(200)
        trip = services.trips.log_trip("A", "B", [Leg("Tricycle", 2, 30), Leg("Bus", 8, 28)])
        services.favorites.save("AB", "A", "B", trip.legs)
        services.savings.set_goal("Goal", 50)
        app = PisoPasaApp(MagicMock(), services)
        app.start()
        for name, view_cls in ROUTES.items():
            with self.subTest(view=name):
                self.assertIsNotNone(view_cls(app).build())
        for period in ("today", "week", "month", "year"):
            app.navigate("home", period=period)
        app.navigate("log", repeat_trip_id=trip.id)
        app.navigate("reports", period="monthly")


if __name__ == "__main__":
    unittest.main()
