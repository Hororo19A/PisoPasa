import tempfile
import unittest
from datetime import date, datetime
from pathlib import Path
from unittest.mock import MagicMock

from app.container import ServiceContainer
from app.developer.dev_app import PANELS, DeveloperApp
from app.developer.diagnostics_service import DiagnosticsService
from app.pisopasa_app import PisoPasaApp
from app.ui.greeting import clock_line, greeting_for


class GreetingTests(unittest.TestCase):
    def test_greeting_by_time(self):
        cases = {4: "gabi", 5: "umaga", 10: "umaga", 11: "tanghali", 12: "tanghali",
                 13: "hapon", 16: "hapon", 17: "hapon", 18: "gabi", 23: "gabi"}
        for hour, word in cases.items():
            self.assertIn(word, greeting_for(datetime(2026, 10, 17, hour, 30)), hour)

    def test_clock_line(self):
        self.assertEqual(clock_line(datetime(2026, 10, 17, 16, 24)), "Saturday, Oct 17 · 4:24 PM")


class LiveSyncTests(unittest.TestCase):
    def test_tick_updates_greeting_and_logo(self):
        with tempfile.TemporaryDirectory() as tmp:
            services = ServiceContainer(":memory:", None, Path(tmp) / "brand")
            app = PisoPasaApp(MagicMock(), services)
            app.start()
            app.navigate("home")
            greeting, _clock = app.live_header
            app.tick(datetime(2026, 10, 17, 7, 0), date(2026, 10, 17))
            self.assertEqual(greeting.value, "Magandang umaga!")
            app.tick(datetime(2026, 10, 17, 15, 0), date(2026, 10, 17))
            self.assertEqual(greeting.value, "Magandang hapon!")
            logo = Path(tmp) / "l.png"
            logo.write_bytes(b"\x89PNG")
            services.branding.set_logo(logo)
            before = app.page.appbar.title
            app.tick(datetime.now(), date.today())
            self.assertIsNot(app.page.appbar.title, before)

    def test_broken_screen_is_caught(self):
        app = PisoPasaApp(MagicMock(), ServiceContainer(":memory:"))
        app.start()

        class Broken:
            def __init__(self, *_a, **_k): raise RuntimeError("boom")
        app.show(Broken)


class DeveloperTests(unittest.TestCase):
    def test_diagnostics(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            services = ServiceContainer(":memory:", None, tmp / "brand")
            diag = DiagnosticsService(services.db, tmp / "x.db", tmp / "log.txt", tmp / "bk")
            self.assertEqual(diag.integrity(), "ok")
            self.assertEqual(diag.table_counts()["fare_matrix"], 4)
            self.assertIn("no log", diag.read_log())
            self.assertTrue(diag.backup().is_file())
            services.wallet.set_starting_balance(100)
            diag.reset_user_data()
            self.assertEqual(services.wallet.status().level, "unset")
            self.assertEqual(diag.table_counts()["fare_matrix"], 4)
            diag.optimize()

    def test_every_panel_builds(self):
        services = ServiceContainer(":memory:")
        app = DeveloperApp(MagicMock(), services)
        app.start()
        for key in PANELS:
            with self.subTest(panel=key):
                app.show(key)


if __name__ == "__main__":
    unittest.main()
