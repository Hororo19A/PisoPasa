import tempfile
import unittest
import zipfile
from pathlib import Path

from app.developer.code_service import CodeError, CodeService


class CodeServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name) / "proj"
        (root / "app").mkdir(parents=True)
        (root / "data").mkdir()
        (root / "app" / "a.py").write_text("x = 1\n", encoding="utf-8")
        (root / "data" / "secret.db").write_text("private")
        (root / "main.py").write_text("print('hi')\n", encoding="utf-8")
        self.root = root
        self.code = CodeService(root, Path(self.tmp.name) / "bk")

    def tearDown(self):
        self.tmp.cleanup()

    def test_list_hides_ignored_and_blocks_escape(self):
        names = [e.name for e in self.code.list_dir("")]
        self.assertIn("app", names)
        self.assertNotIn("data", names)
        for bad in ("../outside.py", "data/secret.db"):
            with self.assertRaises(CodeError):
                self.code.read(bad)

    def test_save_backs_up_and_checks_syntax(self):
        stamp = self.code.write("app/a.py", "x = 2\n")
        self.assertTrue(stamp)
        self.assertEqual((self.root / "app" / "a.py").read_text(), "x = 2\n")
        with self.assertRaises(CodeError) as ctx:
            self.code.write("app/a.py", "def broken(:\n")
        self.assertIn("line 1", str(ctx.exception))
        self.assertEqual((self.root / "app" / "a.py").read_text(), "x = 2\n")
        self.code.restore_backup(stamp)
        self.assertEqual((self.root / "app" / "a.py").read_text(), "x = 1\n")
        self.assertEqual(len(self.code.list_backups()), 2)

    def test_upload_file(self):
        src = Path(self.tmp.name) / "new_tool.py"
        src.write_text("y = 3\n")
        self.code.upload_file(src, "app")
        self.assertTrue((self.root / "app" / "new_tool.py").is_file())
        exe = Path(self.tmp.name) / "evil.exe"
        exe.write_bytes(b"MZ")
        with self.assertRaises(CodeError):
            self.code.upload_file(exe, "app")

    def _zip(self, files: dict[str, str]) -> Path:
        path = Path(self.tmp.name) / "pkg.zip"
        with zipfile.ZipFile(path, "w") as zf:
            for name, text in files.items():
                zf.writestr(name, text)
        return path

    def test_zip_update_strips_wrapper_and_skips_unsafe(self):
        pkg = self._zip({"PisoPasa/app/a.py": "x = 9\n", "PisoPasa/app/b.py": "z = 1\n",
                         "PisoPasa/data/hack.py": "boom = 1\n", "PisoPasa/image.png": "png"})
        written, skipped, backup = self.code.import_zip(pkg)
        self.assertEqual(written, ["app/a.py", "app/b.py"])
        self.assertIn("data/hack.py", skipped)
        self.assertFalse((self.root / "data" / "hack.py").exists())
        self.assertEqual((self.root / "app" / "a.py").read_text(), "x = 9\n")
        self.assertTrue(backup)

    def test_zip_with_one_bad_file_writes_nothing(self):
        pkg = self._zip({"app/a.py": "x = 5\n", "app/bad.py": "def (:\n"})
        with self.assertRaises(CodeError):
            self.code.import_zip(pkg)
        self.assertEqual((self.root / "app" / "a.py").read_text(), "x = 1\n")
        self.assertFalse((self.root / "app" / "bad.py").exists())

    def test_zip_slip_is_ignored(self):
        pkg = self._zip({"../evil.py": "e = 1\n", "app/ok.py": "ok = 1\n"})
        written, skipped, _ = self.code.import_zip(pkg)
        self.assertEqual(written, ["app/ok.py"])
        self.assertFalse((Path(self.tmp.name) / "evil.py").exists())


class ReportTests(unittest.TestCase):
    def test_report_text_has_version_and_no_trip_data(self):
        from app.config import APP_VERSION
        from app.container import ServiceContainer
        from app.models.entities import Leg
        c = ServiceContainer(":memory:")
        c.trips.log_trip("SecretPlace", "Home", [Leg("Jeepney", 5, 15)])
        text = c.export.report_text()
        self.assertIn(APP_VERSION, text)
        self.assertNotIn("SecretPlace", text)


if __name__ == "__main__":
    unittest.main()
