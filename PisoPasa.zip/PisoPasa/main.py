import flet as ft

from app.logging_setup import get_logger
from app.pisopasa_app import PisoPasaApp


def main(page: ft.Page) -> None:
    get_logger().info("PisoPasa started")
    PisoPasaApp(page).start()


if __name__ == "__main__":
    ft.run(main)
